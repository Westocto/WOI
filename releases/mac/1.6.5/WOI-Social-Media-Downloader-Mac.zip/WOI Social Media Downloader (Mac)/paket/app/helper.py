"""WOI Social Media Downloader - Mac yardımcısı.

Penceresi yoktur. Mac'te oturum açılınca (LaunchAgent) arka planda başlar ve
yalnızca Chrome eklentisine hizmet eder: 127.0.0.1:47771 üzerinden indirme
isteklerini alır, yt-dlp ve ffmpeg ile indirir. Kendi yeni sürümünü GitHub'dan
denetler; varsa dosyalarını yeniler ve kapanır, launchd onu yeniden başlatır.
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

import engine
from engine import APP_TITLE, APP_VERSION, Engine
from server import start_server

REPO = "Westocto/WOI"
MANIFEST_URLS = [
    f"https://raw.githubusercontent.com/{REPO}/main/latest-mac.json",
    f"https://github.com/{REPO}/raw/main/latest-mac.json",
    f"https://api.github.com/repos/{REPO}/contents/latest-mac.json",
]
CHECK_EVERY = 6 * 3600
ENGINE_EVERY = 24 * 3600
USER_AGENT = f"WOI-Social-Media-Downloader-mac/{APP_VERSION}"


def install_dir() -> Path:
    """Kurulum klasörü: .../WOI Social Media Downloader (içinde app/, bin/, python/)."""
    return Path(__file__).resolve().parent.parent


def log(msg: str) -> None:
    try:
        with open(engine.data_dir() / "woi.log", "a", encoding="utf-8") as fh:
            fh.write(f"[yardımcı] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except OSError:
        pass


def reveal(path: str) -> None:
    """Dosyayı Finder'da seçili gösterir (klasörse klasörü açar)."""
    try:
        if Path(path).is_file():
            subprocess.Popen(["open", "-R", path])
        else:
            Path(path).mkdir(parents=True, exist_ok=True)
            subprocess.Popen(["open", path])
    except OSError:
        pass


# ---------------------------------------------------------------- güncelleme
def _version_tuple(v: str) -> tuple:
    out = []
    for part in str(v or "").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple((out + [0, 0, 0])[:3])


def _fetch_manifest() -> dict:
    last = None
    for url in MANIFEST_URLS:
        headers = {"User-Agent": USER_AGENT, "Cache-Control": "no-cache"}
        if "api.github.com" in url:
            headers["Accept"] = "application/vnd.github.raw"
        try:
            req = urllib.request.Request(url + ("" if "api.github.com" in url else f"?t={int(time.time())}"),
                                         headers=headers)
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            last = exc
    raise last or RuntimeError("sürüm bilgisi alınamadı")


def _download(url: str, target: Path, progress=None) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as r, open(target, "wb") as fh:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            chunk = r.read(256 * 1024)
            if not chunk:
                break
            fh.write(chunk)
            done += len(chunk)
            if progress and total:
                progress(min(99, int(done * 100 / total)))


class MacUpdater:
    """Eklentinin Ayarlar > Sürüm ve güncellemeler satırı için durum (Windows Updater ile aynı biçim)."""

    def __init__(self, eng: Engine):
        self.eng = eng
        self.lock = threading.Lock()
        self.state = {"status": "idle", "current": APP_VERSION, "latest": "", "percent": 0, "error": ""}
        self.info = None
        self.busy = False

    def get(self) -> dict:
        with self.lock:
            return dict(self.state)

    def _set(self, **kw):
        with self.lock:
            self.state.update(kw)

    def check(self) -> dict:
        """Beklemeden döner; sonuç durumdan okunur."""
        if self.busy:
            return self.get()
        self.busy = True
        self._set(status="checking", error="")

        def run():
            try:
                info = _fetch_manifest()
                latest = str(info.get("version") or "")
                if _version_tuple(latest) > _version_tuple(APP_VERSION):
                    self.info = info
                    self._set(status="available", latest=latest)
                else:
                    self.info = None
                    self._set(status="uptodate", latest=latest)
                    try:
                        self.eng.update_ytdlp()
                    except Exception:
                        pass
            except Exception as exc:
                self._set(status="error", error=str(exc)[:200])
            finally:
                self.busy = False

        threading.Thread(target=run, daemon=True).start()
        return self.get()

    def install(self) -> dict:
        if self.busy:
            return self.get()
        self.busy = True
        self._set(status="downloading", percent=0, error="")

        def run():
            try:
                if self_update(self.eng, self.info, progress=lambda p: self._set(percent=p),
                               waiting=lambda: self._set(status="waiting", percent=100)):
                    self._set(status="installing", percent=100)
                    time.sleep(1.5)  # eklenti "Kuruluyor" durumunu görsün
                    os._exit(0)      # launchd (KeepAlive) yeni sürümü başlatır
                self._set(status="uptodate")
            except Exception as exc:
                self._set(status="error", error=str(exc)[:200])
            finally:
                self.busy = False

        threading.Thread(target=run, daemon=True).start()
        return self.get()


def choose_folder(eng: Engine) -> None:
    """Eklentiden "Değiştir": Mac klasör seçme penceresi; seçilirse ayara yazılır."""
    tr = eng.settings.get()["language"] != "en"
    prompt = "İndirme klasörünü seçin" if tr else "Choose the download folder"
    current = eng.settings.get()["folder"]
    script = ('on run argv\n activate\n'
              ' try\n  set d to POSIX file (item 2 of argv)\n'
              '  return POSIX path of (choose folder with prompt (item 1 of argv) default location d)\n'
              ' on error\n'
              '  try\n   return POSIX path of (choose folder with prompt (item 1 of argv))\n'
              '  on error\n   return ""\n  end try\n'
              ' end try\nend run')
    try:
        out = subprocess.run(["osascript", "-e", script, prompt, current], capture_output=True,
                             timeout=600).stdout.decode("utf-8", "replace").strip()
    except Exception as exc:
        log(f"klasör seçilemedi: {exc}")
        return
    if out:
        eng.settings.update({"folder": out.rstrip("/") or out})


def self_update(eng: Engine, info: dict | None = None, progress=None, waiting=None) -> bool:
    """Yeni sürüm varsa app/ ve Chrome eklentisi dosyalarını yeniler. Yenilediyse True."""
    info = info or _fetch_manifest()
    latest = str(info.get("version") or "")
    if _version_tuple(latest) <= _version_tuple(APP_VERSION):
        return False
    urls = [info["url"], *[u for u in (info.get("mirrors") or []) if isinstance(u, str)]]
    tmp = Path(tempfile.mkdtemp(prefix="woi-update-"))
    try:
        pkg = tmp / "paket.zip"
        last = None
        for u in urls:
            try:
                _download(u, pkg, progress)
                last = None
                break
            except Exception as exc:
                last = exc
        if last:
            raise last
        h = hashlib.sha256(pkg.read_bytes()).hexdigest()
        if h != str(info.get("sha256", "")).lower():
            raise ValueError("paket doğrulanamadı (SHA-256)")
        with zipfile.ZipFile(pkg) as z:
            z.extractall(tmp / "yeni")
        new = tmp / "yeni"
        if not (new / "app" / "helper.py").exists():
            raise ValueError("paket eksik")
        while eng.has_active_jobs():  # süren indirmeler yarıda kalmasın
            if waiting:
                waiting()
            time.sleep(5)
        root = install_dir()
        ext_target = Path(os.environ.get("WOI_EXTENSION_DIR") or (Path.home() / APP_TITLE / "Chrome eklentisi"))
        for src, dst in ((new / "app", root / "app"), (new / "chrome-eklentisi", ext_target)):
            if not src.exists():
                continue
            staging = dst.with_name(dst.name + ".yeni")
            shutil.rmtree(staging, ignore_errors=True)
            shutil.copytree(src, staging)
            old = dst.with_name(dst.name + ".eski")
            shutil.rmtree(old, ignore_errors=True)
            if dst.exists():
                dst.rename(old)
            staging.rename(dst)
            shutil.rmtree(old, ignore_errors=True)
        log(f"güncellendi: {APP_VERSION} -> {latest}")
        return True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def update_loop(eng: Engine) -> None:
    time.sleep(30)
    last_engine = 0.0
    while True:
        try:
            if self_update(eng):
                os._exit(0)  # launchd (KeepAlive) yeni sürümü başlatır
        except Exception as exc:
            log(f"güncelleme denetlenemedi: {exc}")
        if time.time() - last_engine > ENGINE_EVERY and not eng.has_active_jobs():
            last_engine = time.time()
            try:
                eng.update_ytdlp()
            except Exception:
                pass
        time.sleep(CHECK_EVERY)


# ---------------------------------------------------------------- ana
def main() -> None:
    eng = Engine()
    eng.platform = "mac"

    def on_focus():  # eklentideki klasör simgesi: indirme klasörünü aç
        reveal(eng.settings.get()["folder"])

    def on_reveal(job_id):
        job = eng.get_job(job_id)
        if job and job.get("filepath") and Path(job["filepath"]).exists():
            reveal(job["filepath"])
        else:
            on_focus()

    updater = MacUpdater(eng)
    hooks = {
        "choose_folder": lambda: choose_folder(eng),
        "update_state": updater.get,
        "update_check": updater.check,
        "update_install": updater.install,
    }
    httpd = None
    for _ in range(30):  # önceki yardımcı kapanırken port kısa süre dolu olabilir
        httpd = start_server(eng, on_focus, on_reveal, lambda: os._exit(0), hooks)
        if httpd:
            break
        time.sleep(1)
    if not httpd:
        log("127.0.0.1:47771 kullanılamıyor; başka bir kopya çalışıyor olabilir")
        sys.exit(1)
    log(f"başladı {APP_TITLE} {APP_VERSION}")
    if "--no-update" not in sys.argv:
        threading.Thread(target=update_loop, args=(eng,), daemon=True).start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
