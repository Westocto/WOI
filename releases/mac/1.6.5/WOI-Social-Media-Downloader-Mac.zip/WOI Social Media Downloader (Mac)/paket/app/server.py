"""Chrome uzantısının masaüstü uygulamayla konuştuğu yerel sunucu.

Yalnızca 127.0.0.1 üzerinde dinler. İndirme başlatan istekler yalnızca
tarayıcı uzantılarından (chrome-extension:// kökeni) kabul edilir; böylece
sıradan bir web sitesi arka planda indirme tetikleyemez.
"""

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from engine import APP_NAME, APP_TITLE, APP_VERSION, AUDIO_FORMATS, COOKIE_SOURCES, detect_platform

PORT = 47771
EXTENSION_ORIGINS = ("chrome-extension://", "moz-extension://", "edge-extension://")
# Eklentinin Ayarlar menüsünden değiştirilebilen ayarlar
EXTENSION_SETTINGS = {
    "theme": ("dark", "light"),
    "language": ("tr", "en"),
    "audio_format": tuple(AUDIO_FORMATS),
    "cookies_source": tuple(COOKIE_SOURCES),
}


def public_settings(engine, hooks: dict) -> dict:
    """Eklentiye gönderilen ayarlar ve sürüm durumu."""
    s = engine.settings.get()
    upd = hooks.get("update_state")
    return {
        "ok": True, "app": APP_TITLE, "version": APP_VERSION,
        "platform": getattr(engine, "platform", "windows"),
        "rev": engine.settings.rev,
        "folder": s["folder"], "theme": s["theme"], "language": s["language"],
        "video_quality": s["video_quality"], "audio_format": s["audio_format"],
        "cookies_source": s["cookies_source"],
        "update": upd() if upd else {"status": "idle", "current": APP_VERSION},
    }


def _is_extension(origin: str | None) -> bool:
    return bool(origin) and origin.startswith(EXTENSION_ORIGINS)


def make_handler(engine, on_focus, on_reveal=None, on_quit=None, hooks=None):
    hooks = hooks or {}
    class Handler(BaseHTTPRequestHandler):
        server_version = "WOI/1"

        def log_message(self, *args):  # sessiz
            pass

        # ----- yardımcılar -----
        def _cors(self):
            origin = self.headers.get("Origin")
            if _is_extension(origin):
                self.send_header("Access-Control-Allow-Origin", origin)
                self.send_header("Vary", "Origin")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Access-Control-Allow-Headers", "Content-Type")
                self.send_header("Access-Control-Allow-Private-Network", "true")

        def _json(self, code: int, payload):
            body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self._cors()
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict:
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = 0
            if n <= 0 or n > 2_000_000:
                return {}
            try:
                data = json.loads(self.rfile.read(n).decode("utf-8"))
                return data if isinstance(data, dict) else {}
            except ValueError:
                return {}

        def _origin_ok(self) -> bool:
            origin = self.headers.get("Origin")
            # Uzantı dışından gelen (Origin başlığı taşıyan) istekleri reddet.
            return origin is None or _is_extension(origin)

        # ----- yöntemler -----
        def do_OPTIONS(self):
            if not _is_extension(self.headers.get("Origin")):
                self.send_response(403)
                self.end_headers()
                return
            self.send_response(204)
            self._cors()
            self.end_headers()

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path == "/focus":
                on_focus()
                return self._json(200, {"ok": True})
            if not self._origin_ok():
                return self._json(403, {"ok": False})
            if path == "/ping":
                if _is_extension(self.headers.get("Origin")):
                    engine.extension_seen = time.time()
                return self._json(200, public_settings(engine, hooks))
            if path == "/settings":
                return self._json(200, public_settings(engine, hooks))
            if path == "/jobs":
                return self._json(200, {"ok": True, "jobs": engine.list_jobs(3)})
            if path == "/job":  # uzantının arka planı: bitince bildirim göstermek için
                from urllib.parse import parse_qs
                qs = parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                return self._json(200, {"ok": True, "job": engine.get_job((qs.get("id") or [""])[0])})
            return self._json(404, {"ok": False})

        def do_POST(self):
            path = self.path.split("?", 1)[0]
            # Kurulum/kaldırma programı uygulamayı kapatır. Tarayıcılar bu özel
            # başlığı kökensiz bir istekte gönderemediği için web sayfaları kullanamaz.
            if path == "/quit":
                if self.headers.get("Origin") is None and self.headers.get("X-WOI-Installer") == "1" and on_quit:
                    self._json(200, {"ok": True})
                    threading.Timer(0.2, on_quit).start()
                    return
                return self._json(403, {"ok": False})
            # İndirme başlatan uç noktalar yalnızca uzantıdan ve JSON ile.
            if not _is_extension(self.headers.get("Origin")):
                return self._json(403, {"ok": False, "error": "Yalnızca uzantı"})
            if "application/json" not in (self.headers.get("Content-Type") or ""):
                return self._json(415, {"ok": False})
            engine.extension_seen = time.time()
            data = self._body()
            # ----- eklentinin Ayarlar menüsü -----
            if path == "/settings":
                changes = {k: v for k, v in data.items()
                           if k in EXTENSION_SETTINGS and v in EXTENSION_SETTINGS[k]}
                if changes:
                    engine.settings.update(changes)
                return self._json(200, public_settings(engine, hooks))
            if path == "/choose-folder":
                fn = hooks.get("choose_folder")
                if not fn:
                    return self._json(200, {"ok": False})
                # Seçim penceresi açılınca eklenti penceresi kapanır: sonucu beklemeden dön
                threading.Thread(target=fn, daemon=True).start()
                return self._json(200, {"ok": True})
            if path == "/cancel":
                return self._json(200, {"ok": engine.cancel(str(data.get("id") or ""))})
            if path in ("/update-check", "/update-install"):
                fn = hooks.get("update_check" if path == "/update-check" else "update_install")
                st = fn() if fn else {"status": "idle", "current": APP_VERSION}
                return self._json(200, {"ok": True, "update": st})
            url = str(data.get("url") or "")
            cookies = data.get("cookies")
            if isinstance(cookies, list) and detect_platform(url):
                engine.store_cookies(url, cookies)
            if path == "/info":
                return self._json(200, engine.analyze(url))
            if path == "/download":
                res = engine.add_job(url, str(data.get("mode") or "video"),
                                     str(data.get("quality") or ""),
                                     title=str(data.get("title") or "") or None,
                                     container=str(data.get("container") or "mp4"))
                return self._json(200, res)
            if path == "/focus":
                on_focus()
                return self._json(200, {"ok": True})
            if path == "/reveal":
                if on_reveal:
                    on_reveal(str(data.get("id") or ""))
                return self._json(200, {"ok": True})
            return self._json(404, {"ok": False})

    return Handler


class ExclusiveServer(ThreadingHTTPServer):
    """Portu yalnızca bu uygulama kullanabilsin.
    Python'un varsayılanı (SO_REUSEADDR) Windows'ta aynı porta ikinci bir
    uygulamanın da bağlanmasına izin veriyor; bu da tek örnek kontrolünü bozuyordu."""
    # Windows'ta SO_REUSEADDR aynı porta ikinci bir uygulamayı da bağlıyor: kapalı.
    # macOS/Linux'ta yalnızca kapanmış bağlantıların (TIME_WAIT) beklemesini atlatır.
    import os as _os
    allow_reuse_address = _os.name != "nt"

    def server_bind(self):
        import socket
        if hasattr(socket, "SO_EXCLUSIVEADDRUSE"):  # yalnızca Windows
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def start_server(engine, on_focus, on_reveal=None, on_quit=None, hooks=None) -> ThreadingHTTPServer | None:
    """Sunucuyu arka planda başlatır. Port doluysa None döner.
    hooks: choose_folder, update_state, update_check, update_install (isteğe bağlı)."""
    try:
        httpd = ExclusiveServer(("127.0.0.1", PORT), make_handler(engine, on_focus, on_reveal, on_quit, hooks))
    except OSError:
        return None
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    return httpd
