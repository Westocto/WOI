/* Açılışta temanın anında uygulanması (yanıp sönme olmasın): son bilinen tema */
try { if (localStorage.getItem('woi-theme') === 'light') document.documentElement.setAttribute('data-theme', 'light'); } catch (e) { /* yok say */ }
