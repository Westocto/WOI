#!/bin/bash
# WOI Social Media Downloader — Mac'ten kaldırma. İndirdiğiniz dosyalar silinmez.
TITLE="WOI Social Media Downloader"
DEST="$HOME/Library/Application Support/$TITLE"
EXT_ROOT="$HOME/$TITLE"
LABEL="com.westocto.woi.helper"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
TEAL=$'\033[38;2;25;195;177m'; BOLD=$'\033[1m'; OFF=$'\033[0m'

printf "${TEAL}${BOLD}WOI${OFF} ${BOLD}Social Media Downloader${OFF} kaldırılacak.\n"
printf "Yardımcı, ayarlar, geçmiş ve Chrome eklentisi klasörü silinir. İndirdiğiniz videolar silinmez.\n"
read -r -p "Devam edilsin mi? (e/h) " ans
case "$ans" in e|E|evet|Evet|y|Y) ;; *) echo "Vazgeçildi."; exit 0 ;; esac

launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || launchctl unload "$PLIST" 2>/dev/null || true
curl -s -m 3 -X POST -H 'Content-Type: application/json' -H 'X-WOI-Installer: 1' -d '{}' http://127.0.0.1:47771/quit >/dev/null 2>&1 || true
rm -f "$PLIST"
rm -rf "$DEST"
rm -rf "$EXT_ROOT/Chrome eklentisi"
rmdir "$EXT_ROOT" 2>/dev/null || true

printf "\n${TEAL}${BOLD}Kaldırıldı.${OFF}\n"
printf "Son adım: Chrome'da ${BOLD}chrome://extensions${OFF} sayfasından WOI Social Media Downloader eklentisini ${BOLD}Kaldır${OFF} ile silin.\n\n"
