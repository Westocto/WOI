#!/bin/bash
# WOI Social Media Downloader — Mac kurulumu
# Arka plan yardımcısını (pencere yok) ve Chrome eklentisini kurar.
# Yönetici şifresi istemez; her şey kullanıcı klasörüne kurulur.
set -uo pipefail
cd "$(dirname "$0")"
HERE="$(pwd)"
# Kurulum uygulaması (WOI ... Kurulum.app) bu dosyayı WOI_GUI=1 ile çalıştırır:
# renkli çıktı ve Chrome'u açma uygulamaya kalır, adımlar WOI_STATUS dosyasına yazılır.
GUI="${WOI_GUI:-}"
PAKET="${WOI_PAKET:-$HERE/paket}"
STATUS="${WOI_STATUS:-/dev/null}"

TITLE="WOI Social Media Downloader"
DEST="$HOME/Library/Application Support/$TITLE"
EXT="$HOME/$TITLE/Chrome eklentisi"
LABEL="com.westocto.woi.helper"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
UIDN="$(id -u)"

PY_VER="3.12.16+20261026"
PY_BASE="https://github.com/astral-sh/python-build-standalone/releases/download/20261026"
FF_BASE="https://github.com/eugeneware/ffmpeg-static/releases/download/b6.1.1"

case "$(uname -m)" in
  arm64)
    PY_FILE="cpython-$PY_VER-aarch64-apple-darwin-install_only_stripped.tar.gz"
    PY_SHA="353d5f1b4fd2715e7053f12f068435d5bbad16b91e057006b5d01e0925709a7e"
    FF_ARCH="arm64"; FFMPEG_SHA="8923876afa8db5585022d7860ec7e589af192f441c56793971276d450ed3bbfa"
    FFPROBE_SHA="d986a8ec7b030899fe66a8a288ed809a3543338705a3ce178cfb85869c5d80be"
    DENO_FILE="deno-aarch64-apple-darwin.zip" ;;
  x86_64)
    PY_FILE="cpython-$PY_VER-x86_64-apple-darwin-install_only_stripped.tar.gz"
    PY_SHA="37c38fda76fec1fbf310adcbafb7f0d96af13b5511bf8ea954c3aa8eec185734"
    FF_ARCH="x64"; FFMPEG_SHA="929b375c1182d956c51f7ac25e0b2b0411fb01f6f407aa15c9758efeb4242106"
    FFPROBE_SHA="d4da574d6e2e197bd259b47d69cf262df9e312af24ad960444f6d806d3d4c186"
    DENO_FILE="deno-x86_64-apple-darwin.zip" ;;
  *) echo "Bu Mac desteklenmiyor: $(uname -m)"; exit 1 ;;
esac

if [ -n "$GUI" ]; then TEAL=""; DIM=""; BOLD=""; RED=""; OFF=""
else TEAL=$'\033[38;2;25;195;177m'; DIM=$'\033[2m'; BOLD=$'\033[1m'; RED=$'\033[31m'; OFF=$'\033[0m'; fi
step() { printf "\n${TEAL}${BOLD}%s${OFF} %s\n" "$1" "$2"; echo "$1 $2" > "$STATUS"; }
fail() { printf "\n${RED}${BOLD}Kurulum tamamlanamadı:${OFF} %s\n" "$1"; printf "Ayrıntı: %s\n\n" "$DEST/kurulum.log"; echo "HATA $1" > "$STATUS"; exit 1; }
sha_ok() { [ "$(shasum -a 256 "$1" | cut -d' ' -f1)" = "$2" ]; }
fetch() { curl -fL --retry 3 --connect-timeout 20 --progress-bar -o "$2" "$1"; }
sign() {  # Apple Silicon imzasız ikili dosyaları çalıştırmaz: gerekirse yerel imza
  xattr -d com.apple.quarantine "$1" 2>/dev/null || true
  codesign -v "$1" >/dev/null 2>&1 || codesign --force -s - "$1" >/dev/null 2>&1 || true
}

[ -n "$GUI" ] || clear
printf "${TEAL}${BOLD}WOI${OFF} ${BOLD}Social Media Downloader${OFF} — Mac kurulumu\n"
printf "${DIM}YouTube, Vimeo, Instagram, Facebook, X, TikTok ve Pinterest için Chrome eklentisi + arka plan yardımcısı${OFF}\n"

[ -d "$PAKET/app" ] || fail "Bu dosya, zip'ten çıkan klasörün içinden çalıştırılmalı (paket klasörü bulunamadı)."
mkdir -p "$DEST/bin" "$DEST/data" "$HOME/Library/LaunchAgents"
exec 3>>"$DEST/kurulum.log"
echo "===== $(date) kurulum" >&3
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

step "1/6" "Çalışan yardımcı durduruluyor"
launchctl bootout "gui/$UIDN/$LABEL" 2>/dev/null || launchctl unload "$PLIST" 2>/dev/null || true
curl -s -m 3 -X POST -H 'Content-Type: application/json' -H 'X-WOI-Installer: 1' -d '{}' http://127.0.0.1:47771/quit >/dev/null 2>&1 || true
sleep 1

step "2/6" "Python çalışma ortamı"
if [ "$(cat "$DEST/python/.woi-python" 2>/dev/null)" != "$PY_VER" ] || [ ! -x "$DEST/python/bin/python3" ]; then
  fetch "$PY_BASE/$PY_FILE" "$TMP/python.tar.gz" || fail "Python indirilemedi."
  sha_ok "$TMP/python.tar.gz" "$PY_SHA" || fail "Python dosyası doğrulanamadı (SHA-256)."
  rm -rf "$TMP/py" && mkdir -p "$TMP/py"
  tar -xzf "$TMP/python.tar.gz" -C "$TMP/py" || fail "Python açılamadı."
  rm -rf "$DEST/python" && mv "$TMP/py/python" "$DEST/python" || fail "Python yerleştirilemedi."
  echo "$PY_VER" > "$DEST/python/.woi-python"
else
  echo "${DIM}  zaten kurulu${OFF}"
fi
PY="$DEST/python/bin/python3"
xattr -dr com.apple.quarantine "$DEST/python" 2>/dev/null || true

step "3/6" "Uygulama dosyaları"
rm -rf "$DEST/app" && cp -R "$PAKET/app" "$DEST/app" || fail "Uygulama dosyaları kopyalanamadı."
cp "$HERE/Kaldir.command" "$DEST/Kaldir.command" 2>/dev/null && chmod +x "$DEST/Kaldir.command"
find "$DEST/app" -name '__pycache__' -prune -exec rm -rf {} + 2>/dev/null

step "4/6" "İndirme motoru (yt-dlp, ffmpeg, Deno)"
if [ -f "$DEST/bin/yt-dlp" ]; then
  "$PY" "$DEST/bin/yt-dlp" -U >&3 2>&1 || true
else
  fetch "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp" "$DEST/bin/yt-dlp" || fail "yt-dlp indirilemedi."
fi
for tool in ffmpeg ffprobe; do
  if [ ! -x "$DEST/bin/$tool" ]; then
    [ "$tool" = ffmpeg ] && want="$FFMPEG_SHA" || want="$FFPROBE_SHA"
    fetch "$FF_BASE/$tool-darwin-$FF_ARCH.gz" "$TMP/$tool.gz" || fail "$tool indirilemedi."
    sha_ok "$TMP/$tool.gz" "$want" || fail "$tool dosyası doğrulanamadı (SHA-256)."
    gunzip -c "$TMP/$tool.gz" > "$DEST/bin/$tool" && chmod +x "$DEST/bin/$tool"
    sign "$DEST/bin/$tool"
  fi
done
if [ ! -x "$DEST/bin/deno" ]; then
  if fetch "https://github.com/denoland/deno/releases/latest/download/$DENO_FILE" "$TMP/deno.zip" && \
     unzip -o -q "$TMP/deno.zip" deno -d "$DEST/bin"; then
    chmod +x "$DEST/bin/deno"; sign "$DEST/bin/deno"
  else
    echo "  Deno kurulamadı (isteğe bağlı; bazı YouTube videoları etkilenebilir)" | tee -a /dev/fd/3
  fi
fi
"$DEST/bin/ffmpeg" -version >/dev/null 2>&1 || fail "ffmpeg bu Mac'te çalışmadı."

step "5/6" "Chrome eklentisi"
mkdir -p "$EXT"
rm -rf "$EXT" && mkdir -p "$EXT" && cp -R "$PAKET/chrome-eklentisi/." "$EXT/" || fail "Eklenti kopyalanamadı."

step "6/6" "Arka plan yardımcısı (oturum açılınca kendiliğinden başlar)"
cat > "$PLIST" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array><string>$PY</string><string>$DEST/app/helper.py</string></array>
  <key>WorkingDirectory</key><string>$DEST/app</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>PYTHONUTF8</key><string>1</string>
    <key>PYTHONDONTWRITEBYTECODE</key><string>1</string>
    <key>WOI_EXTENSION_DIR</key><string>$EXT</string>
    <key>PATH</key><string>$DEST/bin:/usr/bin:/bin:/usr/sbin:/sbin</string>
  </dict>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>ProcessType</key><string>Background</string>
  <key>StandardOutPath</key><string>$DEST/data/yardimci.log</string>
  <key>StandardErrorPath</key><string>$DEST/data/yardimci.log</string>
</dict>
</plist>
PL
launchctl bootstrap "gui/$UIDN" "$PLIST" 2>&3 || launchctl load -w "$PLIST" 2>&3 || fail "Yardımcı başlatılamadı."
ok=""
for i in $(seq 1 20); do
  if curl -s -m 2 http://127.0.0.1:47771/ping | grep -q '"ok": true'; then ok=1; break; fi
  sleep 1
done
[ -n "$ok" ] || fail "Yardımcı başladı ama yanıt vermiyor."

printf "\n${TEAL}${BOLD}Kurulum tamamlandı.${OFF}\n\n"
printf "${BOLD}Son adım — Chrome'a eklentiyi ekleyin (bir kez):${OFF}\n"
printf "  1. Açılan Chrome sekmesinde (chrome://extensions) sağ üstteki ${BOLD}Geliştirici modu${OFF}'nu açın.\n"
printf "  2. ${BOLD}Paketlenmemiş öğe yükle${OFF}'ye tıklayın.\n"
printf "  3. Açılan pencerede ${BOLD}Cmd+Shift+G${OFF}'ye basın, ${BOLD}Cmd+V${OFF} ile yapıştırıp Enter'a basın, sonra ${BOLD}Seç${OFF}'e tıklayın.\n"
printf "     ${DIM}(Eklenti klasörünün yolu panoya kopyalandı: %s)${OFF}\n" "$EXT"
printf "  4. Yapboz simgesinden ${BOLD}WOI Social Media Downloader${OFF}'ı araç çubuğuna sabitleyin.\n\n"
printf "İndirilenler: ${BOLD}%s${OFF}\n" "$HOME/Downloads/$TITLE"
printf "Kaldırmak için: ${BOLD}%s${OFF}\n\n" "$DEST/Kaldir.command"
echo "===== $(date) tamam" >&3
echo "TAMAM" > "$STATUS"
if [ -z "$GUI" ]; then
  printf "%s" "$EXT" | pbcopy
  open -a "Google Chrome" "chrome://extensions" 2>/dev/null || open -b com.google.Chrome 2>/dev/null || true
fi
