"""WOI Social Media Downloader - Mac yardımcısı.

Penceresi yoktur. Mac'te oturum açılınca (LaunchAgent) arka planda başlar ve
yalnızca Chrome eklentisine hizmet eder: 127.0.0.1:47771 üzerinden indirme
isteklerini alır, yt-dlp ve ffmpeg ile indirir. Kendi yeni sürümünü GitHub'dan
denetler; varsa dosyalarını yeniler ve kapanır, launchd onu yeniden başlatır.
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

import engine
from engine import APP_TITLE, APP_VERSION, Engine
from server import start_server

REPO = "Westocto/WOI"
MANIFEST_URLS = [
    f"https://raw.githubusercontent.com/{REPO}/main/latest-mac.json",
    f"https://github.com/{REPO}/raw/main/latest-mac.json",
    f"https://api.github.com/repos/{REPO}/contents/latest-mac.json",
]
CHECK_EVERY = 6 * 3600
ENGINE_EVERY = 24 * 3600
USER_AGENT = f"WOI-Social-Media-Downloader-mac/{APP_VERSION}"


def install_dir() -> Path:
    """Kurulum klasörü: .../WOI Social Media Downloader (içinde app/, bin/, python/)."""
    return Path(__file__).resolve().parent.parent


def log(msg: str) -> None:
    try:
        with open(engine.data_dir() / "woi.log", "a", encoding="utf-8") as fh:
            fh.write(f"[yardımcı] {time.strftime('%Y-%m-%d %H:%M:%S')} {msg}\n")
    except OSError:
        pass


def reveal(path: str) -> None:
    """Dosyayı Finder'da seçili gösterir (klasörse klasörü açar)."""
    try:
        if Path(path).is_file():
            subprocess.Popen(["open", "-R", path])
        else:
            Path(path).mkdir(parents=True, exist_ok=True)
            subprocess.Popen(["open", path])
    except OSError:
        pass


# ---------------------------------------------------------------- güncelleme
def _version_tuple(v: str) -> tuple:
    out = []
    for part in str(v or "").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple((out + [0, 0, 0])[:3])


def _fetch_manifest() -> dict:
    last = None
    for url in MANIFEST_URLS:
        headers = {"User-Agent": USER_AGENT, "Cache-Control": "no-cache"}
        if "api.github.com" in url:
            headers["Accept"] = "application/vnd.github.raw"
        try:
            req = urllib.request.Request(url + ("" if "api.github.com" in url else f"?t={int(time.time())}"),
                                         headers=headers)
            with urllib.request.urlopen(req, timeout=20) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as exc:
            last = exc
    raise last or RuntimeError("sürüm bilgisi alınamadı")


def _download(url: str, target: Path) -> None:
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=60) as r, open(target, "wb") as fh:
        shutil.copyfileobj(r, fh, 256 * 1024)


def self_update(eng: Engine) -> bool:
    """Yeni sürüm varsa app/ ve Chrome eklentisi dosyalarını yeniler. Yenilediyse True."""
    info = _fetch_manifest()
    latest = str(info.get("version") or "")
    if _version_tuple(latest) <= _version_tuple(APP_VERSION):
        return False
    urls = [info["url"], *[u for u in (info.get("mirrors") or []) if isinstance(u, str)]]
    tmp = Path(tempfile.mkdtemp(prefix="woi-update-"))
    try:
        pkg = tmp / "paket.zip"
        last = None
        for u in urls:
            try:
                _download(u, pkg)
                last = None
                break
            except Exception as exc:
                last = exc
        if last:
            raise last
        h = hashlib.sha256(pkg.read_bytes()).hexdigest()
        if h != str(info.get("sha256", "")).lower():
            raise ValueError("paket doğrulanamadı (SHA-256)")
        with zipfile.ZipFile(pkg) as z:
            z.extractall(tmp / "yeni")
        new = tmp / "yeni"
        if not (new / "app" / "helper.py").exists():
            raise ValueError("paket eksik")
        while eng.has_active_jobs():  # süren indirmeler yarıda kalmasın
            time.sleep(5)
        root = install_dir()
        ext_target = Path(os.environ.get("WOI_EXTENSION_DIR") or (Path.home() / APP_TITLE / "Chrome eklentisi"))
        for src, dst in ((new / "app", root / "app"), (new / "chrome-eklentisi", ext_target)):
            if not src.exists():
                continue
            staging = dst.with_name(dst.name + ".yeni")
            shutil.rmtree(staging, ignore_errors=True)
            shutil.copytree(src, staging)
            old = dst.with_name(dst.name + ".eski")
            shutil.rmtree(old, ignore_errors=True)
            if dst.exists():
                dst.rename(old)
            staging.rename(dst)
            shutil.rmtree(old, ignore_errors=True)
        log(f"güncellendi: {APP_VERSION} -> {latest}")
        return True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def update_loop(eng: Engine) -> None:
    time.sleep(30)
    last_engine = 0.0
    while True:
        try:
            if self_update(eng):
                os._exit(0)  # launchd (KeepAlive) yeni sürümü başlatır
        except Exception as exc:
            log(f"güncelleme denetlenemedi: {exc}")
        if time.time() - last_engine > ENGINE_EVERY and not eng.has_active_jobs():
            last_engine = time.time()
            try:
                eng.update_ytdlp()
            except Exception:
                pass
        time.sleep(CHECK_EVERY)


# ---------------------------------------------------------------- ana
def main() -> None:
    eng = Engine()
    eng.platform = "mac"

    def on_focus():  # eklentideki klasör simgesi: indirme klasörünü aç
        reveal(eng.settings.get()["folder"])

    def on_reveal(job_id):
        job = eng.get_job(job_id)
        if job and job.get("filepath") and Path(job["filepath"]).exists():
            reveal(job["filepath"])
        else:
            on_focus()

    httpd = None
    for _ in range(30):  # önceki yardımcı kapanırken port kısa süre dolu olabilir
        httpd = start_server(eng, on_focus, on_reveal, lambda: os._exit(0))
        if httpd:
            break
        time.sleep(1)
    if not httpd:
        log("127.0.0.1:47771 kullanılamıyor; başka bir kopya çalışıyor olabilir")
        sys.exit(1)
    log(f"başladı {APP_TITLE} {APP_VERSION}")
    if "--no-update" not in sys.argv:
        threading.Thread(target=update_loop, args=(eng,), daemon=True).start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
