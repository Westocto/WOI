/* WOI Social Media Downloader – Chrome uzantısı */
'use strict';

const API = 'http://127.0.0.1:47771';
const VIDEO = ['2160p', '1440p', '1080p', '720p'];
const AUDIO = ['MP3', 'WAV'];
const PLATFORMS = [
  ['YouTube', ['youtube.com', 'youtu.be'], ['youtube.com']],
  ['Vimeo', ['vimeo.com'], ['vimeo.com']],
  ['Instagram', ['instagram.com'], ['instagram.com']],
  ['Facebook', ['facebook.com', 'fb.watch'], ['facebook.com']],
  ['X', ['x.com', 'twitter.com'], ['x.com', 'twitter.com']],
  ['TikTok', ['tiktok.com'], ['tiktok.com']]
];

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------- dil (uygulamanın ayarını izler)
const I18N = {
  tr: {
    download: 'İndir', downloads: 'İndirilenler', video: 'Video', audio: 'Ses', mode: 'İndirme türü', quality: 'Kalite',
    best: 'En iyi', open_app: 'Uygulamayı aç', app_on: 'Uygulama bağlı', app_off: 'Uygulama kapalı',
    app_check: 'Uygulama kontrol ediliyor', reading: 'Sayfa okunuyor…', analyzing: 'Çözümleniyor…', no_video: 'Bu sayfada desteklenen video yok',
    app_closed: 'WOI uygulaması kapalı', app_closed_sub: 'Sağ üstteki simgeyle uygulamayı açın',
    mac_closed: 'WOI yardımcısı çalışmıyor', mac_closed_sub: 'Kur.command dosyasını yeniden çalıştırın',
    open_folder: 'İndirme klasörünü aç',
    sending: 'Gönderiliyor…', queued_ok: 'Kuyruğa eklendi', send_failed: 'Gönderilemedi', unreachable: 'Uygulamaya ulaşılamadı',
    queued: 'Sırada', starting: 'Hazırlanıyor', processing: 'İşleniyor', done: 'Tamamlandı', show_file: 'Klasörde göster',
    error: 'Hata', canceled: 'İptal edildi', empty: 'Henüz indirme yok',
    highest: 'En yüksek', na_pre: '', na_post: ' için yok', container: 'Dosya biçimi', audio_fmt: 'Ses biçimi',
    max_pre: '', max_mid: ' için en yüksek ', picked_pre: '', picked_mid: ' için en yüksek: ',
    dl_as_pre: '', dl_as_post: ' indiriliyor'
  },
  en: {
    download: 'Download', downloads: 'Downloads', video: 'Video', audio: 'Audio', mode: 'Download type', quality: 'Quality',
    best: 'Best', open_app: 'Open app', app_on: 'App connected', app_off: 'App closed',
    app_check: 'Checking app', reading: 'Reading page…', analyzing: 'Analyzing…', no_video: 'No supported video on this page',
    app_closed: 'WOI app is closed', app_closed_sub: 'Open the app with the icon at top right',
    mac_closed: 'WOI helper is not running', mac_closed_sub: 'Run Kur.command again',
    open_folder: 'Open download folder',
    sending: 'Sending…', queued_ok: 'Added to queue', send_failed: 'Could not send', unreachable: 'App not reachable',
    queued: 'Queued', starting: 'Preparing', processing: 'Processing', done: 'Completed', show_file: 'Show in folder',
    error: 'Error', canceled: 'Canceled', empty: 'No downloads yet',
    highest: 'Highest', na_pre: 'Not available in ', na_post: '', container: 'File format', audio_fmt: 'Audio format',
    max_pre: 'Highest for ', max_mid: ': ', picked_pre: 'Highest for ', picked_mid: ': ',
    dl_as_pre: 'Downloading ', dl_as_post: ''
  },
};
const ENGINE_EN = {
  'Giriş gerekli': 'Login required', 'Özel içerik': 'Private content', 'Desteklenmeyen bağlantı': 'Unsupported link',
  'Biçim bulunamadı': 'Format not available', 'İçerik bulunamadı': 'Content not found', 'Bağlantı hatası': 'Connection error',
  'Hata': 'Error', 'Geçerli bir bağlantı değil.': 'Not a valid link.', 'Diğer': 'Other'
};
let lang = 'tr';
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const t = (k) => { const d = I18N[lang] || I18N.tr; return has(d, k) ? d[k] : has(I18N.tr, k) ? I18N.tr[k] : k; };
const te = (x) => (lang === 'en' && ENGINE_EN[x]) || x;
const pctText = (n) => (lang === 'en' ? n + '%' : '%' + n);

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  document.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = t(el.dataset.i18nTitle); });
}
const st = {
  tab: null, url: '', platform: null, online: false, settings: null,
  mode: 'video', container: 'mp4', analyzing: false, quality: { video: '2160p', audio: 'MP3' }, title: '', jobId: null
};

function detect(url) {
  let host = '';
  try { host = new URL(url).hostname.toLowerCase(); } catch (e) { return null; }
  for (const p of PLATFORMS) {
    if (p[1].some((d) => host === d || host.endsWith('.' + d))) return p;
  }
  return null;
}

function cleanTitle(t) {
  return (t || '')
    .replace(/^\(\d+\)\s*/, '')
    .replace(/\s*[-|•]\s*(YouTube|Vimeo|Instagram|Facebook|TikTok|X)\s*$/i, '')
    .replace(/\s+on X:.*$/i, '')
    .trim();
}

async function call(path, body) {
  const opts = body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    : {};
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), path === '/info' ? 95000 : 4000);
  try {
    const r = await fetch(API + path, { ...opts, signal: ctrl.signal });
    return await r.json();
  } finally {
    clearTimeout(timer);
  }
}

async function cookiesFor(platform) {
  if (!platform || !st.settings || st.settings.cookies_source !== 'extension') return undefined;
  const out = [];
  for (const domain of platform[2]) {
    try {
      const list = await chrome.cookies.getAll({ domain });
      for (const c of list) {
        out.push({
          domain: c.domain, name: c.name, value: c.value, path: c.path, secure: c.secure,
          httpOnly: c.httpOnly, hostOnly: c.hostOnly, expirationDate: c.expirationDate || 0
        });
      }
    } catch (e) { /* izin yoksa geç */ }
  }
  return out;
}

// ---------------------------------------------------------------- görünüm
function setStatus(kind) {
  const el = $('status');
  el.className = 'status' + (kind === 'on' ? ' on' : kind === 'off' ? ' off' : '');
  const label = t(kind === 'on' ? 'app_on' : kind === 'off' ? 'app_off' : 'app_check');
  el.setAttribute('aria-label', label);
  el.title = label;
}

let mediaState = null;  // [title, meta, warn] – not gösterildikten sonra geri dönmek için
function setMedia(title, meta, warn) {
  mediaState = [title, meta, warn];
  $('title').textContent = title;
  $('title').className = 'title' + (warn ? ' warn' : '');
  const m = $('meta');
  m.classList.remove('note');
  m.textContent = meta || '\u00a0';
  if (st.analyzing && !warn) {  // çözümleme sürerken
    m.appendChild(document.createTextNode(' · '));
    const b = document.createElement('span');
    b.className = 'busy';
    b.textContent = t('analyzing');
    m.appendChild(b);
  } else if (maxRes() && !warn && st.mode === 'video') {
    m.appendChild(document.createTextNode(' · '));
    const mx = document.createElement('span');
    mx.id = 'm-max';
    mx.textContent = t('max_pre') + boxName() + t('max_mid') + maxRes() + 'p';
    m.appendChild(mx);
  }
}

let noteTimer = null;
function showNote(text) {
  clearTimeout(noteTimer);
  const m = $('meta');
  m.textContent = text;
  m.classList.add('note');
  noteTimer = setTimeout(() => { if (mediaState) setMedia(...mediaState); }, 3000);
}

const qHeight = (q) => parseInt(q, 10) || 0;
const boxName = () => st.container.toUpperCase();
// Seçili biçim (MP4/MKV) için videonun en yüksek çözünürlüğü ve fps'i
const useMp4 = () => st.container === 'mp4' && st.info && st.info.max_mp4;
const maxRes = () => (st.info ? (useMp4() ? st.info.max_mp4 : st.info.max_res) : null);
const maxFps = () => (st.info ? (useMp4() ? (st.info.max_fps_mp4 || st.info.max_fps) : st.info.max_fps) : null);
function isAvailable(q) {
  if (st.mode !== 'video' || !maxRes()) return true;
  return qHeight(q) <= maxRes();
}
function bestAvailable() {
  return VIDEO.find(isAvailable) || VIDEO[VIDEO.length - 1];
}
function flashButton(q, times) {
  const b = [...$('quality').children].find((x) => x.dataset.q === q);
  if (!b) return;
  b.classList.remove('flash');
  void b.offsetWidth;
  b.style.animationIterationCount = times;
  b.classList.add('flash');
}
function flashMax() {
  const m = $('m-max');
  if (!m) return;
  m.classList.remove('flash');
  void m.offsetWidth;
  m.classList.add('flash');
}
const fpsText = () => (maxFps() ? ' · ' + maxFps() + ' fps' : '');

// Sol düğme: videoda MP4 | MKV, seste WAV | MP3. Seste çözünürlük yok.
const fmtPair = () => (st.mode === 'video' ? ['mp4', 'mkv'] : ['WAV', 'MP3']);
function pickFmt(side) {
  const v = fmtPair()[side];
  if (st.mode === 'video') {
    st.container = v;
    // Çözümleme bittiyse: bu biçimde indirilebilecek en yüksek çözünürlük seçilir
    if (st.info && !st.analyzing) st.quality.video = bestAvailable();
  } else st.quality.audio = v;
  renderQuality();
  if (mediaState) setMedia(...mediaState);
}
function renderQuality() {
  const video = st.mode === 'video';
  const list = video ? VIDEO : [];
  const cur = st.quality.video;
  $('mode-video').setAttribute('aria-pressed', video);
  $('mode-audio').setAttribute('aria-pressed', !video);
  const pair = fmtPair();
  const sel = video ? st.container : st.quality.audio;
  $('fmt').setAttribute('aria-label', t(video ? 'container' : 'audio_fmt'));
  $('fmt-left').textContent = pair[0].toUpperCase();
  $('fmt-right').textContent = pair[1].toUpperCase();
  $('fmt-left').setAttribute('aria-pressed', sel === pair[0]);
  $('fmt-right').setAttribute('aria-pressed', sel === pair[1]);
  $('quality').innerHTML = '';
  for (const q of list) {
    const b = document.createElement('button');
    b.textContent = q;
    b.dataset.q = q;
    if (st.analyzing) {  // çözümlenirken hepsi pasif, hiçbiri seçili görünmez
      b.className = 'busy';
      b.setAttribute('aria-pressed', 'false');
      b.setAttribute('aria-disabled', 'true');
      b.title = t('analyzing');
      $('quality').appendChild(b);
      continue;
    }
    b.setAttribute('aria-pressed', q === cur);
    const ok = isAvailable(q);
    if (!ok) {
      b.className = 'na';
      b.setAttribute('aria-disabled', 'true');
      b.title = t('na_pre') + boxName() + t('na_post');
    }
    b.onclick = () => {
      if (!ok) {
        // Videoda olmayan çözünürlük seçilemez: en yüksek mevcut olan seçilir, 3 kez parlar
        const best = bestAvailable();
        st.quality.video = best;
        renderQuality();
        persist();
        flashButton(best, 3);
        flashMax();
        return;
      }
      st.quality.video = q;
      renderQuality();
      persist();
    };
    $('quality').appendChild(b);
  }
}

function updateButton() {
  $('download').disabled = !(st.online && st.platform) || st.analyzing;
}

function persist() {
  // MP4 ve ses biçimi her açılışta varsayılandan başlar; yalnızca tür ve çözünürlük hatırlanır
  try { chrome.storage.local.set({ mode: st.mode, video: st.quality.video }); } catch (e) { /* yok say */ }
}

// ---------------------------------------------------------------- son indirilenler
function jobRow(j) {
  const row = document.createElement('div');
  row.className = 'job';
  const top = document.createElement('div');
  top.className = 'job-top';
  const title = document.createElement('span');
  title.className = 'job-title';
  title.textContent = j.title || '';
  title.title = j.title || '';
  const metaParts = j.mode === 'audio' ? [j.quality] : (j.res ? [j.res].concat(j.fps ? [j.fps + ' fps'] : []) : []);
  if (j.mode !== 'audio' && metaParts.length) {
    const ext = (j.filepath || '').split('.').pop().toLowerCase();
    const box = ext === 'mp4' || ext === 'mkv' ? ext : (j.container || '');
    if (box) metaParts.push(box.toUpperCase());
  }
  if (metaParts.length) {
    const sm = document.createElement('span');
    sm.className = 'job-meta';
    sm.textContent = ' · ' + metaParts.join(' · ');
    title.appendChild(sm);
  }
  const pct = Math.round(j.percent || 0);
  let right;
  if (j.status === 'done') {
    right = document.createElement('button');
    right.className = 'job-right done';
    right.textContent = t('done');
    right.title = t('show_file');
    right.onclick = () => { call('/reveal', { id: j.id }).catch(() => {}); };
  } else {
    right = document.createElement('span');
    right.className = 'job-right' + (j.status === 'error' ? ' err' : '');
    right.textContent = {
      queued: t('queued'), starting: t('starting'), downloading: pctText(pct), processing: t('processing'),
      error: te(j.error || 'Hata'), canceled: t('canceled')
    }[j.status] || '';
    if (j.status === 'error' && j.detail) right.title = j.detail;
  }
  top.append(title, right);
  row.appendChild(top);
  if (j.status === 'downloading' || j.status === 'processing') {
    const bar = document.createElement('div');
    bar.className = 'bar';
    const fill = document.createElement('div');
    fill.style.width = (j.status === 'processing' ? 100 : pct) + '%';
    bar.appendChild(fill);
    row.appendChild(bar);
  }
  return row;
}

let lastJobsKey = '';
function renderJobs(jobs) {
  const key = JSON.stringify((jobs || []).map((j) => [j.id, j.status, Math.round(j.percent || 0), j.title, j.res, j.filepath]));
  if (key === lastJobsKey) return;
  lastJobsKey = key;
  const box = $('jobs');
  box.innerHTML = '';
  if (!jobs || !jobs.length) {
    const e = document.createElement('div');
    e.className = 'empty';
    e.textContent = t('empty');
    box.appendChild(e);
    return;
  }
  for (const j of jobs.slice(0, 3)) box.appendChild(jobRow(j));
}

async function pollJobs() {
  if (!st.online) return;
  try {
    const r = await call('/jobs');
    renderJobs((r && r.jobs) || []);
  } catch (e) { /* uygulama kapandıysa sessiz */ }
}

// ---------------------------------------------------------------- akış
async function download() {
  if ($('download').disabled || st.analyzing) return;
  if (st.mode === 'video') {
    let q = st.quality.video;
    const picked = !isAvailable(q);
    if (picked) { q = bestAvailable(); st.quality.video = q; renderQuality(); persist(); }
    flashButton(q, 2);
    showNote(picked ? t('picked_pre') + boxName() + t('picked_mid') + q + fpsText()
                    : t('dl_as_pre') + q + fpsText() + ' · ' + boxName() + t('dl_as_post'));
  } else {
    showNote(t('dl_as_pre') + st.quality.audio + t('dl_as_post'));
  }
  $('download').disabled = true;
  $('download').textContent = t('sending');
  try {
    const res = await call('/download', {
      url: st.url, mode: st.mode, quality: st.quality[st.mode], container: st.container,
      title: st.title || undefined, cookies: await cookiesFor(st.platform)
    });
    if (res && res.ok) {
      st.jobId = res.job.id;
      track(res.job);
      pollJobs();
      $('download').textContent = t('queued_ok');
    } else {
      $('download').textContent = te(res && res.error) || t('send_failed');
    }
  } catch (e) {
    $('download').textContent = t('unreachable');
  }
  setTimeout(() => { $('download').textContent = t('download'); updateButton(); }, 1800);
}

// Arka plan, iş bitince "İndirme tamamlandı" bildirimini gösterir (background.js)
function track(job) {
  try { chrome.runtime.sendMessage({ type: 'track', id: job.id, title: job.title || st.title || '' }); } catch (e) { /* yok say */ }
}

// Mac'te masaüstü penceresi yok: arka plan yardımcısı çalışır, simge indirme klasörünü açar
const IS_MAC = /mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || navigator.userAgent);
const FOLDER_ICON = '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.6l2 2h7.4A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/></svg>';
function setupMac() {
  if (!IS_MAC) return;
  const b = $('open-app');
  b.innerHTML = FOLDER_ICON;
  b.dataset.i18nAria = 'open_folder';
  b.dataset.i18nTitle = 'open_folder';
  b.setAttribute('aria-label', t('open_folder'));
  b.title = t('open_folder');
}

async function openApp() {
  if (IS_MAC && !st.online) return;  // yardımcı kapalıysa açılacak bir şey yok
  if (st.online) {
    try { await call('/focus', {}); } catch (e) { /* yok say */ }
  } else if (st.tab) {
    // Kurulumda kaydedilen woi:// adresi uygulamayı başlatır.
    chrome.tabs.update(st.tab.id, { url: 'woi://open' });
  }
  window.close();
}

async function init() {
  const remedia = () => { if (mediaState) setMedia(...mediaState); };
  $('mode-video').onclick = () => { st.mode = 'video'; renderQuality(); persist(); remedia(); };
  $('mode-audio').onclick = () => { st.mode = 'audio'; renderQuality(); persist(); remedia(); };
  $('fmt-left').onclick = () => pickFmt(0);
  $('fmt-right').onclick = () => pickFmt(1);
  $('download').onclick = download;
  $('open-app').onclick = openApp;

  try {
    const saved = await chrome.storage.local.get(['mode', 'video', 'quality', 'lang']);
    if (saved.mode === 'video' || saved.mode === 'audio') st.mode = saved.mode;
    const v = saved.video || (saved.quality && saved.quality.video);  // eski sürüm 'quality' saklıyordu
    if (VIDEO.includes(v)) st.quality.video = v;
    if (saved.lang) lang = saved.lang;
  } catch (e) { /* yok say */ }
  setupMac();
  applyLanguage();
  setMedia(t('reading'), '');
  renderQuality();
  renderJobs([]);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  st.tab = tab;
  st.url = (tab && tab.url) || '';
  st.platform = detect(st.url);
  st.title = cleanTitle(tab && tab.title);

  // Uygulama açık mı?
  try {
    const ping = await call('/ping');
    st.online = !!(ping && ping.ok);
    st.settings = ping;
    if (ping && (ping.language === 'en' || ping.language === 'tr') && ping.language !== lang) {
      lang = ping.language;
      try { chrome.storage.local.set({ lang }); } catch (e) { /* yok say */ }
      applyLanguage();
      renderQuality();
      lastJobsKey = '';
      renderJobs([]);
    }
    if (ping) {
      if (AUDIO.includes(ping.audio_format)) st.quality.audio = ping.audio_format;  // varsayılan MP3
      const saved = await chrome.storage.local.get(['video', 'quality']);
      if (!saved.video && !saved.quality && VIDEO.includes(ping.video_quality)) st.quality.video = ping.video_quality;
      renderQuality();
    }
  } catch (e) {
    st.online = false;
  }
  setStatus(st.online ? 'on' : 'off');
  st.analyzing = !!(st.online && st.platform);
  renderQuality();

  if (!st.platform) {
    setMedia(t('no_video'), 'YouTube · Vimeo · Instagram · Facebook · X · TikTok', true);
  } else if (!st.online) {
    if (IS_MAC) setMedia(t('mac_closed'), t('mac_closed_sub'), true);
    else setMedia(t('app_closed'), t('app_closed_sub'), true);
  } else {
    setMedia(st.title || st.platform[0], st.platform[0]);
  }
  updateButton();
  if (!st.online) return;

  pollJobs();
  setInterval(pollJobs, 800);

  if (st.platform) {
    let info = null;
    try {
      info = await call('/info', { url: st.url, cookies: await cookiesFor(st.platform) });
    } catch (e) { /* sayfa başlığıyla devam */ }
    st.analyzing = false;
    if (info && info.ok) {
      st.title = info.title;
      st.info = info;
      // En yüksek çözünürlük bulundu: seçili biçimde indirilebilecek en yükseği seçili gelir
      st.quality.video = bestAvailable();
      renderQuality();
      setMedia(info.title, [te(info.platform), info.duration].filter(Boolean).join(' · '));
    } else {
      renderQuality();
      setMedia(st.title || st.platform[0], st.platform[0] + (info && info.error ? ' · ' + te(info.error) : ''), false);
    }
    updateButton();
  }
}

init();
