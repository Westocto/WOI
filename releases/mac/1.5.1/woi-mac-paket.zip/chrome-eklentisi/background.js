/* WOI Social Media Downloader – arka plan: uzantıdan başlatılan indirmeleri izler,
   bitince "İndirme tamamlandı" bildirimi gösterir. Bildirime tıklanınca
   indirme klasörü açılır ve dosya seçili olur. */
'use strict';

const API = 'http://127.0.0.1:47771';
const POLL_MS = 1500;
const TEXT = {
  tr: { done: 'İndirme tamamlandı', click: 'Klasörde göstermek için tıklayın' },
  en: { done: 'Download complete', click: 'Click to show in folder' }
};

async function getTracked() {
  try { return (await chrome.storage.local.get('track')).track || {}; } catch (e) { return {}; }
}
async function setTracked(track) {
  try { await chrome.storage.local.set({ track }); } catch (e) { /* yok say */ }
}
async function lang() {
  try { return (await chrome.storage.local.get('lang')).lang === 'en' ? 'en' : 'tr'; } catch (e) { return 'tr'; }
}

async function call(path, body) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 4000);
  try {
    const opts = body
      ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
      : {};
    const r = await fetch(API + path, { ...opts, signal: ctrl.signal });
    return await r.json();
  } finally {
    clearTimeout(timer);
  }
}

function metaOf(j) {
  if (j.mode === 'audio') return j.quality || '';
  const parts = [];
  if (j.res) parts.push(j.res);
  if (j.fps) parts.push(j.fps + ' fps');
  const ext = (j.filepath || '').split('.').pop().toLowerCase();
  const box = ext === 'mp4' || ext === 'mkv' ? ext : (j.container || '');
  if (box) parts.push(box.toUpperCase());
  return parts.join(' · ');
}

async function notifyDone(j, fallbackTitle) {
  const L = TEXT[await lang()];
  const title = j.title && j.title !== j.url ? j.title : (fallbackTitle || 'WOI Social Media Downloader');
  const meta = metaOf(j);
  chrome.notifications.create('woi:' + j.id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: L.done,
    message: meta ? title + ' · ' + meta : title,
    contextMessage: 'WOI Social Media Downloader · ' + L.click,
    priority: 1,
    isClickable: true
  });
}

let running = false;
async function poll() {
  if (running) return;
  running = true;
  try {
    for (;;) {
      const track = await getTracked();  // uzantı API çağrısı: arka planı uyanık tutar
      const ids = Object.keys(track);
      if (!ids.length) break;
      let changed = false;
      for (const id of ids) {
        let res;
        try { res = await call('/job?id=' + encodeURIComponent(id)); } catch (e) { res = null; }
        const entry = track[id];
        if (!res) {  // uygulama kapalı: bir süre sonra izlemeyi bırak
          if (Date.now() - entry.added > 6 * 3600 * 1000) { delete track[id]; changed = true; }
          continue;
        }
        const j = res.job;
        if (!j || j.status === 'error' || j.status === 'canceled') { delete track[id]; changed = true; continue; }
        if (j.status === 'done') {
          await notifyDone(j, entry.title);
          delete track[id];
          changed = true;
        }
      }
      if (changed) await setTracked(track);
      if (!Object.keys(track).length) break;
      await new Promise((r) => setTimeout(r, POLL_MS));
    }
  } finally {
    running = false;
  }
  if (!Object.keys(await getTracked()).length) chrome.alarms.clear('woi-poll');
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'track' || !msg.id) return;
  (async () => {
    const track = await getTracked();
    track[msg.id] = { title: msg.title || '', added: Date.now() };
    await setTracked(track);
    // Tarayıcı arka planı kapatırsa diye yedek uyandırma
    chrome.alarms.create('woi-poll', { periodInMinutes: 0.5 });
    poll();
  })();
});

chrome.alarms.onAlarm.addListener((a) => { if (a.name === 'woi-poll') poll(); });
chrome.runtime.onStartup.addListener(poll);

chrome.notifications.onClicked.addListener((nid) => {
  if (!nid.startsWith('woi:')) return;
  const id = nid.slice(4);
  call('/reveal', { id }).catch(() => {});
  chrome.notifications.clear(nid);
});
