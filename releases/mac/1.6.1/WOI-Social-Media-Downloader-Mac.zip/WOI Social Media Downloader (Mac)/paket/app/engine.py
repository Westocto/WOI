"""WOI Social Media Downloader - indirme motoru.

yt-dlp ve ffmpeg'i alt süreç olarak çalıştırır, kuyruğu yönetir,
ilerlemeyi okur, ayarları ve geçmişi saklar.
"""

import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

APP_NAME = "WOI downloader"  # veri ve kurulum klasörlerinin adı (değişmez)
APP_TITLE = "WOI Social Media Downloader"  # görünen ad
APP_VERSION = "1.6.1"
IS_WINDOWS = os.name == "nt"
NO_WINDOW = 0x08000000 if IS_WINDOWS else 0  # CREATE_NO_WINDOW

VIDEO_QUALITIES = ["2160p", "1440p", "1080p", "720p"]
AUDIO_FORMATS = ["MP3", "WAV"]
CONTAINERS = ["mp4", "mkv"]

# MP4 kabının yeniden kodlama olmadan, yaygın oynatıcı ve düzenleyicilerde
# sorunsuz açılacak şekilde taşıyabildiği video kodekleri. YouTube'un 4K/1440p
# akışları çoğu zaman VP9'dur; bunlar MP4'e konmaz, MKV'de kalır.
# 1.6.1: MP4 = H.264 görüntü + AAC ses. QuickTime ve Premiere AV1/VP9'u (ve Opus sesi) açamıyor;
# bu yüzden yalnızca her programda açılan H.264 seçilir.
MP4_VCODEC_RE = re.compile(r"^(avc|h264)", re.I)
MP4_VCODEC_FILTER = "[vcodec~='^(avc|h264)']"
COMPAT_VCODECS = ("h264",)
COMPAT_ACODECS = ("aac", "mp3", "alac")
COOKIE_SOURCES = ["extension", "firefox", "edge", "none"]

PLATFORMS = [
    ("YouTube", ("youtube.com", "youtu.be", "youtube-nocookie.com")),
    ("Vimeo", ("vimeo.com",)),
    ("Instagram", ("instagram.com",)),
    ("Facebook", ("facebook.com", "fb.watch", "fb.com")),
    ("X", ("x.com", "twitter.com")),
    ("TikTok", ("tiktok.com",)),
    ("Pinterest", ("pinterest.com", "pinterest.com.tr", "pinterest.co.uk", "pinterest.de", "pinterest.fr",
                   "pinterest.es", "pinterest.it", "pinterest.ca", "pinterest.com.au", "pinterest.com.mx",
                   "pinterest.jp", "pinterest.ch", "pinterest.at", "pinterest.pt", "pinterest.nl", "pinterest.ru",
                   "pinterest.dk", "pinterest.ie", "pinterest.nz", "pinterest.cl", "pinterest.co.kr", "pin.it")),
]


# --------------------------------------------------------------------------
# Yollar
# --------------------------------------------------------------------------

def base_dir() -> Path:
    """Uygulamanın (exe ya da main.py) bulunduğu klasör."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


IS_MAC = sys.platform == "darwin"


def data_dir() -> Path:
    if os.environ.get("WOI_DATA_DIR"):
        d = Path(os.environ["WOI_DATA_DIR"])
    elif IS_MAC:  # Mac yardımcısı: ~/Library/Application Support/WOI Social Media Downloader/data
        d = Path.home() / "Library" / "Application Support" / APP_TITLE / "data"
    else:
        root = os.environ.get("APPDATA") or str(Path.home() / ".config")
        d = Path(root) / APP_NAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def find_binary(name: str) -> str | None:
    env = os.environ.get("WOI_" + name.upper().replace("-", "_"))
    if env and Path(env).exists():
        return env
    exe = name + (".exe" if IS_WINDOWS else "")
    for cand in (base_dir() / "bin" / exe, base_dir().parent / "bin" / exe):
        if cand.exists():
            return str(cand)
    return shutil.which(name)


def default_folder() -> str:
    return str(Path.home() / "Downloads" / APP_TITLE)


# --------------------------------------------------------------------------
# Yardımcılar
# --------------------------------------------------------------------------

def detect_platform(url: str) -> str | None:
    try:
        host = (urlparse(url.strip()).hostname or "").lower()
    except ValueError:
        return None
    for name, domains in PLATFORMS:
        for d in domains:
            if host == d or host.endswith("." + d):
                return name
    return None


def normalize_url(url: str) -> str:
    """Pinterest: kısa bağlantıyı (pin.it) açar, ülke alan adlarını www.pinterest.com'a çevirir
    (yt-dlp her ülke uzantısını tanımıyor).
    TikTok: yt-dlp yalnızca www.tiktok.com/@kullanıcı/video/ID biçimini tanır; m.tiktok.com,
    www'suz adresler, /photo/ ve sorgu ekleri bu biçime çevrilir."""
    url = (url or "").strip()
    platform = detect_platform(url)
    if platform == "TikTok":
        m = re.search(r"tiktok\.com/(?:@([\w.-]+)/)?(?:video|photo)/(\d+)", url)
        if m:
            return f"https://www.tiktok.com/@{m.group(1) or '_'}/video/{m.group(2)}"
        m = re.search(r"tiktok\.com/(?:embed(?:/v2)?|share/video)/(\d+)", url)
        if m:
            return f"https://www.tiktok.com/@_/video/{m.group(1)}"
        return url
    if platform != "Pinterest":
        return url
    host = (urlparse(url).hostname or "").lower()
    if host == "pin.it" or host.endswith(".pin.it"):
        try:
            import urllib.request
            req = urllib.request.Request(url, method="GET", headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=15) as r:
                url = r.geturl()
        except Exception:
            return url
    m = re.search(r"/pin/(?:[\w-]+--)?(\d+)", url)
    if m:
        return f"https://www.pinterest.com/pin/{m.group(1)}/"
    return url


def best_image(info: dict) -> str:
    """Görsel pin: en büyük görselin adresi (Pinterest 'originals' sürümünü tercih eder)."""
    thumbs = [t for t in (info.get("thumbnails") or []) if t.get("url")]
    for t in thumbs:
        if "/originals/" in t["url"]:
            return t["url"]
    if thumbs:
        return max(thumbs, key=lambda t: (t.get("width") or 0) * (t.get("height") or 0) or t.get("preference") or 0)["url"]
    return info.get("thumbnail") or ""


def looks_like_url(text: str) -> bool:
    try:
        p = urlparse(text.strip())
    except ValueError:
        return False
    return p.scheme in ("http", "https") and bool(p.netloc)


def friendly_error(raw: str) -> tuple[str, str]:
    """(kısa durum metni, ayrıntı) döndürür."""
    text = (raw or "").strip()
    low = text.lower()
    if any(k in low for k in ("login", "log in", "sign in", "cookies", "authentication",
                              "logged-in", "age-restricted", "confirm your age")):
        return "Giriş gerekli", text
    if "private" in low:
        return "Özel içerik", text
    if "unsupported url" in low:
        return "Desteklenmeyen bağlantı", text
    if "requested format" in low or "only images are available" in low:
        return "Biçim bulunamadı", text
    if "not available" in low or "unavailable" in low or "removed" in low or "404" in low or "does not exist" in low:
        return "İçerik bulunamadı", text
    if "unable to download webpage" in low or "network" in low or "timed out" in low:
        return "Bağlantı hatası", text
    return "Hata", text


def fmt_duration(seconds) -> str:
    try:
        s = int(float(seconds))
    except (TypeError, ValueError):
        return ""
    h, rem = divmod(s, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def cookies_to_netscape(cookies: list) -> str:
    lines = ["# Netscape HTTP Cookie File", "# WOI Social Media Downloader tarafından oluşturuldu", ""]
    for c in cookies or []:
        try:
            domain = str(c.get("domain", ""))
            name = str(c.get("name", ""))
            if not domain or not name:
                continue
            host_only = bool(c.get("hostOnly", False))
            if not host_only and not domain.startswith("."):
                domain = "." + domain
            if c.get("httpOnly"):
                domain = "#HttpOnly_" + domain
            expiry = int(float(c.get("expirationDate") or 0))
            lines.append("\t".join([
                domain,
                "FALSE" if host_only else "TRUE",
                str(c.get("path") or "/"),
                "TRUE" if c.get("secure") else "FALSE",
                str(expiry),
                name,
                str(c.get("value", "")).replace("\n", "").replace("\t", ""),
            ]))
        except (TypeError, ValueError):
            continue
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------------------
# Ayarlar
# --------------------------------------------------------------------------

DEFAULT_SETTINGS = {
    "folder": default_folder(),
    "video_quality": "2160p",
    "audio_format": "MP3",
    "cookies_source": "extension",
    "transparent": True,
    "opacity": 60,
    "language": "tr",
    "theme": "dark",  # dark | light (uygulama ve Chrome eklentisi)
    "ui_version": 2,
    "update_notified": "",  # bu sürüm için "yeni sürüm" bildirimi gösterildi
}


class Settings:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.Lock()
        self.data = dict(DEFAULT_SETTINGS)
        self.rev = 0              # her değişiklikte artar: uygulama ve eklenti eşitlenir
        self.listeners = []       # değişince çağrılır: fn(yeni_ayarlar, değişen_anahtarlar)
        try:
            loaded = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(loaded, dict):
                self.data.update({k: v for k, v in loaded.items() if k in DEFAULT_SETTINGS})
                if int(loaded.get("ui_version", 1) or 1) < 2:  # yeni tasarım: daha saydam varsayılan
                    self.data["opacity"] = DEFAULT_SETTINGS["opacity"]
                    self.data["ui_version"] = 2
        except (OSError, ValueError):
            pass
        self._validate()

    def _validate(self):
        d = self.data
        if d["video_quality"] == "En iyi":  # eski sürümden kalan ayar
            d["video_quality"] = "2160p"
        if d["video_quality"] not in VIDEO_QUALITIES:
            d["video_quality"] = DEFAULT_SETTINGS["video_quality"]
        if d["audio_format"] not in AUDIO_FORMATS:
            d["audio_format"] = DEFAULT_SETTINGS["audio_format"]
        if d["cookies_source"] not in COOKIE_SOURCES:
            d["cookies_source"] = DEFAULT_SETTINGS["cookies_source"]
        try:
            d["opacity"] = max(30, min(100, int(d["opacity"])))
        except (TypeError, ValueError):
            d["opacity"] = DEFAULT_SETTINGS["opacity"]
        d["transparent"] = bool(d["transparent"])
        if d["language"] not in ("tr", "en"):
            d["language"] = "tr"
        if d["theme"] not in ("dark", "light"):
            d["theme"] = "dark"
        if not isinstance(d["folder"], str) or not d["folder"].strip():
            d["folder"] = default_folder()

    def get(self) -> dict:
        with self.lock:
            return dict(self.data)

    def update(self, changes: dict) -> dict:
        with self.lock:
            before = dict(self.data)
            for k, v in (changes or {}).items():
                if k in DEFAULT_SETTINGS:
                    self.data[k] = v
            self._validate()
            changed = [k for k in self.data if self.data[k] != before.get(k)]
            if changed:
                self.rev += 1
            try:
                self.path.write_text(json.dumps(self.data, ensure_ascii=False, indent=2),
                                     encoding="utf-8")
            except OSError:
                pass
            out = dict(self.data)
        if changed:
            for fn in list(self.listeners):
                try:
                    fn(out, changed)
                except Exception:
                    pass
        return out


# --------------------------------------------------------------------------
# Motor
# --------------------------------------------------------------------------

# Ses indirmelerinde ara dosya, aynı videonun daha önce indirilmiş MP4'üyle
# çakışmasın diye geçici bir ek alır; iş bitince ek kaldırılır.
AUDIO_MARK = "~ses"

PROGRESS_RE = re.compile(r"^\[WOI\]\s*([\d.]+)%?\|([^|]*)\|(.*)$")
FILE_RE = re.compile(r"^\[WOIFILE\]\s*(.+)$")
META_RE = re.compile(r"^\[WOIMETA\]\s*([^|]*)\|([^|]*)\|(.*)$")


class Engine:
    MAX_PARALLEL = 2
    HISTORY_LIMIT = 50

    def __init__(self):
        self.dir = data_dir()
        (self.dir / "cookies").mkdir(exist_ok=True)
        self.settings = Settings(self.dir / "settings.json")
        self.jobs: dict[str, dict] = {}
        self.order: list[str] = []
        self.procs: dict[str, subprocess.Popen] = {}
        self.lock = threading.Lock()
        self.wake = threading.Event()
        self.extension_seen = 0.0
        self._load_history()
        for _ in range(self.MAX_PARALLEL):
            threading.Thread(target=self._worker, daemon=True).start()

    # ----- yardımcı -----

    def _ytdlp(self) -> str | None:
        return find_binary("yt-dlp")

    def _ffmpeg_dir(self) -> str | None:
        f = find_binary("ffmpeg")
        return str(Path(f).parent) if f else None

    def _run_args(self, args: list[str]) -> list[str]:
        exe = self._ytdlp()
        if not exe:
            raise RuntimeError("yt-dlp bulunamadı. Kurulumu yeniden çalıştırın.")
        if exe.endswith(".exe") or IS_WINDOWS:
            return [exe, *args]
        # Linux/macOS: zip biçimindeki (platformdan bağımsız) yt-dlp, uygulamanın kendi Python'uyla çalışır;
        # tek parça çalıştırılabilir dosya (yt-dlp_macos gibi) doğrudan çalışır.
        import zipfile
        if zipfile.is_zipfile(exe):
            return [sys.executable, exe, *args]
        return [exe, *args]

    @staticmethod
    def _env() -> dict:
        env = dict(os.environ)
        env["PYTHONUTF8"] = "1"
        env["PYTHONIOENCODING"] = "utf-8"
        return env

    def cookie_file_for(self, platform: str | None) -> Path | None:
        if not platform:
            return None
        return self.dir / "cookies" / f"{platform.lower()}.txt"

    def store_cookies(self, url: str, cookies: list) -> None:
        platform = detect_platform(url)
        path = self.cookie_file_for(platform)
        if path and cookies:
            try:
                path.write_text(cookies_to_netscape(cookies), encoding="utf-8")
            except OSError:
                pass

    def _js_args(self) -> list[str]:
        deno = find_binary("deno")
        return ["--js-runtimes", "deno:" + deno] if deno else []

    def _cookie_plan(self, url: str) -> list[bool]:
        """Hangi sırayla denenecek: True = oturum çerezleriyle.
        YouTube ve Vimeo herkese açık videolarda çerez istemez, oturumla indirmek
        ise kısıtlı biçim listesine yol açabiliyor; bu yüzden önce çerezsiz dene."""
        if not self._cookie_args(url):
            return [False]
        if detect_platform(url) in ("YouTube", "Vimeo", "Pinterest"):
            return [False, True]
        return [True, False]

    def _cookie_args(self, url: str) -> list[str]:
        src = self.settings.get()["cookies_source"]
        if src == "none":
            return []
        if src in ("firefox", "edge"):
            return ["--cookies-from-browser", src]
        path = self.cookie_file_for(detect_platform(url))
        if path and path.exists():
            return ["--cookies", str(path)]
        return []

    # ----- çözümleme -----

    def analyze(self, url: str) -> dict:
        url = (url or "").strip()
        if not looks_like_url(url):
            return {"ok": False, "error": "Geçerli bir bağlantı değil."}
        url = normalize_url(url)
        result = None
        for use_cookies in self._cookie_plan(url):
            args = ["-J", "--no-playlist", "--no-warnings", "--skip-download",
                    "--ignore-no-formats-error", *self._js_args(),
                    *(self._cookie_args(url) if use_cookies else []), "--", url]
            try:
                proc = subprocess.run(self._run_args(args), capture_output=True, timeout=90,
                                      env=self._env(), creationflags=NO_WINDOW)
            except subprocess.TimeoutExpired:
                result = {"ok": False, "error": "Bağlantı hatası", "detail": "Zaman aşımı"}
                continue
            except (OSError, RuntimeError) as exc:
                return {"ok": False, "error": "Hata", "detail": str(exc)}
            out = proc.stdout.decode("utf-8", "replace")
            err = proc.stderr.decode("utf-8", "replace")
            if proc.returncode == 0 and out.strip():
                result = None
                break
            short, detail = friendly_error(_last_error(err))
            result = {"ok": False, "error": short, "detail": detail}
        if result is not None:
            return result
        try:
            info = json.loads(out.strip().splitlines()[-1])
        except ValueError:
            return {"ok": False, "error": "Hata", "detail": "Yanıt okunamadı"}
        if info.get("_type") == "playlist" and info.get("entries"):
            info = next((e for e in info["entries"] if e), info)
        platform = detect_platform(url) or info.get("extractor_key") or "Diğer"
        max_res, max_fps = _best_video(info)
        mp4_res, mp4_fps = _best_video(info, mp4_only=True)
        # Pinterest'te videosuz pin: görsel indirilir
        has_video = any(f.get("vcodec") != "none" for f in (info.get("formats") or []))
        image = best_image(info) if platform == "Pinterest" and not has_video and not max_res else ""
        return {
            "is_image": bool(image),
            "image_url": image,
            "max_res": max_res,  # MKV: her şey
            "max_fps": max_fps,
            "max_mp4": mp4_res,
            "max_fps_mp4": mp4_fps,
            "ok": True,
            "title": info.get("title") or info.get("fulltitle") or "İsimsiz",
            "uploader": info.get("uploader") or info.get("channel") or info.get("uploader_id") or "",
            "duration": fmt_duration(info.get("duration")),
            "thumbnail": info.get("thumbnail") or "",
            "platform": platform,
        }

    # ----- kuyruk -----

    def add_job(self, url: str, mode: str, quality: str, title: str | None = None,
                container: str | None = None) -> dict:
        url = (url or "").strip()
        if not looks_like_url(url):
            return {"ok": False, "error": "Geçerli bir bağlantı değil."}
        url = normalize_url(url)
        mode = mode if mode in ("audio", "image") else "video"
        valid = AUDIO_FORMATS if mode == "audio" else VIDEO_QUALITIES
        s = self.settings.get()
        if mode == "image":
            quality = "Görsel"
        elif quality not in valid:
            quality = s["audio_format"] if mode == "audio" else s["video_quality"]
        container = "mp4"  # 1.6.0: tüm videolar MP4 (MKV seçeneği kaldırıldı)
        job = {
            "id": uuid.uuid4().hex[:12],
            "url": url,
            "title": title or url,
            "platform": detect_platform(url) or "Diğer",
            "mode": mode,
            "quality": quality,
            "container": container if mode == "video" else "",
            "status": "queued",
            "percent": 0.0,
            "eta": "",
            "speed": "",
            "filepath": "",
            "res": "",
            "fps": "",
            "error": "",
            "detail": "",
            "created": time.time(),
        }
        with self.lock:
            self.jobs[job["id"]] = job
            self.order.insert(0, job["id"])
        self.wake.set()
        return {"ok": True, "job": dict(job)}

    def cancel(self, job_id: str) -> bool:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job or job["status"] in ("done", "error", "canceled"):
                return False
            job["status"] = "canceled"
            proc = self.procs.get(job_id)
        if proc:
            _kill_tree(proc)
        self._save_history()
        return True

    def remove_finished(self) -> None:
        with self.lock:
            keep = [j for j in self.order
                    if self.jobs[j]["status"] not in ("done", "error", "canceled")]
            for j in self.order:
                if j not in keep:
                    self.jobs.pop(j, None)
            self.order = keep
        self._save_history()

    def list_jobs(self, limit: int = 3) -> list[dict]:
        with self.lock:
            return [dict(self.jobs[j]) for j in self.order[:limit]]

    def has_active_jobs(self) -> bool:
        with self.lock:
            return any(j["status"] in ("queued", "starting", "downloading", "processing")
                       for j in self.jobs.values())

    def get_job(self, job_id: str) -> dict | None:
        with self.lock:
            j = self.jobs.get(job_id)
            return dict(j) if j else None

    def _next_job(self) -> dict | None:
        with self.lock:
            for jid in reversed(self.order):  # en eski bekleyen önce
                j = self.jobs[jid]
                if j["status"] == "queued":
                    j["status"] = "starting"
                    return j
        return None

    def _worker(self):
        while True:
            job = self._next_job()
            if not job:
                self.wake.wait(1.0)
                self.wake.clear()
                continue
            try:
                self._download(job)
            except Exception as exc:  # beklenmeyen hata kuyruğu durdurmasın
                with self.lock:
                    job["status"] = "error"
                    job["error"], job["detail"] = "Hata", str(exc)
            self._save_history()

    def build_download_args(self, job: dict, use_cookies: bool = True, simple: bool = False) -> list[str]:
        s = self.settings.get()
        folder = s["folder"]
        Path(folder).mkdir(parents=True, exist_ok=True)
        args = [
            "--no-playlist", "--newline", "--no-colors", "--progress",
            "--progress-template",
            "download:[WOI] %(progress._percent_str)s|%(progress._eta_str)s|%(progress._speed_str)s",
            "--print", "after_move:[WOIFILE] %(filepath)s",
            "--print", "after_move:[WOIMETA] %(width|)s|%(height|)s|%(fps|)s",
            "-P", folder,
            "-P", "temp:" + str(self.dir / "tmp" / job["id"]),
            "-o", ("%(title).120B [%(id)s]" + AUDIO_MARK + ".%(ext)s") if job["mode"] == "audio"
                  else "%(title).110B [%(id)s]%(height& {}p|)s%(fps&{:.0f}|)s.%(ext)s",
            "--windows-filenames",
            *self._js_args(),
        ]
        ff = self._ffmpeg_dir()
        if ff:
            args += ["--ffmpeg-location", ff]
        if job["mode"] == "audio":
            fmt = "wav" if job["quality"] == "WAV" else "mp3"
            if not simple:
                args += ["-f", "ba/b"]
            args += ["-x", "--audio-format", fmt, "--audio-quality", "0"]
        else:
            height = {"2160p": 2160, "1440p": 1440, "1080p": 1080, "720p": 720}.get(job["quality"])
            res = f"res:{height}" if height else "res"
            mp4 = job.get("container", "mp4") != "mkv"
            if simple:  # sitenin sunduğu ne varsa, yalnızca çözünürlük tercihiyle
                args += ["-S", f"{res},vcodec:h264,ext:mp4:m4a" if mp4 else res]
            elif mp4:
                # MP4: yalnızca MP4'e uyan kodekler (H.264/H.265/AV1) ve tercihen AAC ses.
                # Önce çözünürlük, sonra fps. Yeniden kodlama yok (kayıpsız birleştirme).
                v = "bv*" + MP4_VCODEC_FILTER
                args += ["-f", f"{v}+ba[acodec~='^(mp4a|aac)']/{v}+ba/b[ext=mp4]/bv*[ext=mp4]+ba/b",
                         "-S", f"{res},fps"]
            else:
                # MKV: her kodek girer, sitenin sunduğu en yüksek kalite.
                args += ["-f", "bv*+ba/b", "-S", f"{res},fps"]
            if mp4:
                args += ["--merge-output-format", "mp4"]
            else:
                args += ["--merge-output-format", "mkv", "--remux-video", "mkv"]
        if use_cookies:
            args += self._cookie_args(job["url"])
        args += ["--", job["url"]]
        return args

    def _download_image(self, job: dict):
        """Görsel pin: görseli doğrudan indirir."""
        import urllib.request
        info = self.analyze(job["url"])
        img = info.get("image_url") if info.get("ok") else ""
        if not img:
            with self.lock:
                job["status"] = "error"
                job["error"], job["detail"] = (info.get("error") or "İçerik bulunamadı"), (info.get("detail") or "Görsel bulunamadı")
            return
        if info.get("title") and (not job.get("title") or job["title"] == job["url"]):
            job["title"] = info["title"]
        ext = os.path.splitext(urlparse(img).path)[1].lower() or ".jpg"
        if ext not in (".jpg", ".jpeg", ".png", ".webp", ".gif"):
            ext = ".jpg"
        folder = Path(self.settings.get()["folder"])
        folder.mkdir(parents=True, exist_ok=True)
        pin = (re.search(r"/pin/(\d+)", job["url"]) or [None, "pin"])[1]
        base = re.sub(r'[<>:"/\\|?*\x00-\x1f]', " ", job.get("title") or "Pinterest")[:110].strip() or "Pinterest"
        target = folder / f"{base} [{pin}]{ext}"
        n = 2
        while target.exists():
            target = folder / f"{base} [{pin}] ({n}){ext}"
            n += 1
        with self.lock:
            job["status"] = "downloading"
        try:
            req = urllib.request.Request(img, headers={"User-Agent": "Mozilla/5.0", "Referer": "https://www.pinterest.com/"})
            with urllib.request.urlopen(req, timeout=60) as r, open(target, "wb") as fh:
                total = int(r.headers.get("Content-Length") or 0)
                done = 0
                while True:
                    chunk = r.read(128 * 1024)
                    if not chunk:
                        break
                    with self.lock:
                        if job["status"] == "canceled":
                            break
                    fh.write(chunk)
                    done += len(chunk)
                    if total:
                        with self.lock:
                            job["percent"] = done * 100.0 / total
            with self.lock:
                if job["status"] == "canceled":
                    target.unlink(missing_ok=True)
                    return
                job["filepath"], job["status"], job["percent"] = str(target), "done", 100.0
                job["res"] = ""
        except Exception as exc:
            target.unlink(missing_ok=True)
            with self.lock:
                job["status"] = "error"
                job["error"], job["detail"] = friendly_error(str(exc))

    def _download(self, job: dict):
        if job["mode"] == "image":
            return self._download_image(job)
        if not job.get("title") or job["title"] == job["url"]:
            info = self.analyze(job["url"])
            if info.get("ok"):
                with self.lock:
                    job["title"] = info["title"]
        attempts = [(c, False) for c in self._cookie_plan(job["url"])]
        tried = set()
        last_errors: list[str] = []
        log_lines: list[str] = []
        while attempts:
            use_cookies, simple = attempts.pop(0)
            if (use_cookies, simple) in tried:
                continue
            tried.add((use_cookies, simple))
            with self.lock:
                if job["status"] == "canceled":
                    return
                job["status"] = "downloading"
                job["percent"], job["eta"], job["speed"] = 0.0, "", ""
            rc, errors, lines = self._run_download(job, self.build_download_args(job, use_cookies, simple))
            with self.lock:
                if job["status"] == "canceled":
                    return
            if rc == 0:
                with self.lock:
                    if job["filepath"]:
                        job["filepath"] = _strip_audio_mark(job["filepath"])
                if job["mode"] == "video" and job.get("filepath"):
                    if not self._ensure_compatible(job):
                        return  # iptal edildi ya da dönüştürülemedi (durum ayarlandı)
                with self.lock:
                    job["status"] = "done"
                    job["percent"] = 100.0
                    job["eta"] = ""
                return
            last_errors = errors or last_errors
            log_lines += [f"--- deneme: çerez={use_cookies} basit={simple} çıkış={rc}"] + lines[-40:]
            msg = (errors[-1] if errors else "").lower()
            if ("requested format" in msg or "only images" in msg) and not simple:
                attempts.insert(0, (use_cookies, True))
        with self.lock:
            job["status"] = "error"
            job["error"], job["detail"] = friendly_error(last_errors[-1] if last_errors else "")
        self._log_failure(job, log_lines)

    # ----- uyumluluk -----

    def _probe_codecs(self, path: str) -> tuple[str, str, float]:
        """(görüntü kodeki, ses kodeki, süre sn). Bilinmiyorsa boş."""
        probe = find_binary("ffprobe")
        if not probe:
            return "", "", 0.0
        try:
            out = subprocess.run([probe, "-v", "error", "-show_entries", "stream=codec_type,codec_name:format=duration",
                                  "-of", "json", path], capture_output=True, timeout=60,
                                 creationflags=NO_WINDOW).stdout.decode("utf-8", "replace")
            data = json.loads(out or "{}")
        except Exception:
            return "", "", 0.0
        v = next((st.get("codec_name", "") for st in data.get("streams", []) if st.get("codec_type") == "video"), "")
        a = next((st.get("codec_name", "") for st in data.get("streams", []) if st.get("codec_type") == "audio"), "")
        try:
            dur = float((data.get("format") or {}).get("duration") or 0)
        except (TypeError, ValueError):
            dur = 0.0
        return v, a, dur

    def _ensure_compatible(self, job: dict) -> bool:
        """İnen MP4 QuickTime/Premiere'de açılmayacak bir kodekteyse (AV1, VP9, Opus, HEVC…)
        H.264 + AAC'ye çevirir. Sorun yoksa dokunmaz. Devam edilebiliyorsa True."""
        path = job["filepath"]
        if not Path(path).exists():
            return True
        vcodec, acodec, duration = self._probe_codecs(path)
        if not vcodec:  # ffprobe yok ya da okunamadı: olduğu gibi bırak
            return True
        v_ok = vcodec in COMPAT_VCODECS
        a_ok = not acodec or acodec in COMPAT_ACODECS
        if v_ok and a_ok and path.lower().endswith(".mp4"):
            return True
        ff = find_binary("ffmpeg")
        if not ff:
            return True
        with self.lock:
            if job["status"] == "canceled":
                return False
            job["status"], job["percent"], job["eta"] = "processing", 0.0, ""
        src = Path(path)
        dst = src.with_name(src.stem + ".woi-uyumlu.mp4")
        args = [ff, "-y", "-hide_banner", "-nostats", "-progress", "pipe:1", "-i", str(src),
                "-map", "0:v:0", "-map", "0:a:0?"]
        args += (["-c:v", "copy"] if v_ok else
                 ["-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p"])
        args += ["-tag:v", "avc1"]
        args += (["-c:a", "copy"] if a_ok else ["-c:a", "aac", "-b:a", "192k"])
        args += ["-movflags", "+faststart", str(dst)]
        try:
            proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                    creationflags=NO_WINDOW)
        except OSError:
            return True
        with self.lock:
            self.procs[job["id"]] = proc
        for raw in proc.stdout:
            line = raw.decode("utf-8", "replace").strip()
            if line.startswith("out_time_us=") and duration > 0:
                try:
                    done = int(line.split("=", 1)[1]) / 1_000_000
                    with self.lock:
                        job["percent"] = max(0.0, min(99.0, done * 100 / duration))
                except ValueError:
                    pass
        rc = proc.wait()
        with self.lock:
            self.procs.pop(job["id"], None)
            canceled = job["status"] == "canceled"
        if canceled or rc != 0 or not dst.exists():
            dst.unlink(missing_ok=True)
            if canceled:
                return False
            return True  # dönüştürülemediyse en azından indirilen dosya kalsın
        final = src.with_suffix(".mp4")
        try:
            os.replace(dst, final)
            if final != src:
                src.unlink(missing_ok=True)
        except OSError:
            return True
        with self.lock:
            job["filepath"] = str(final)
            job["container"] = "mp4"
        return True

    def _run_download(self, job: dict, args: list[str]) -> tuple[int, list[str], list[str]]:
        try:
            proc = subprocess.Popen(self._run_args(args), stdout=subprocess.PIPE,
                                    stderr=subprocess.STDOUT, env=self._env(),
                                    creationflags=NO_WINDOW)
        except (OSError, RuntimeError) as exc:
            return 1, [str(exc)], [str(exc)]
        with self.lock:
            self.procs[job["id"]] = proc
        errors: list[str] = []
        lines: list[str] = []
        last_pct = 0.0
        for raw in iter(proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").strip()
            if not line:
                continue
            m = PROGRESS_RE.match(line)
            if m:
                try:
                    pct = float(m.group(1))
                except ValueError:
                    pct = last_pct
                last_pct = pct
                with self.lock:
                    if job["status"] == "canceled":
                        break
                    job["percent"] = pct
                    job["eta"] = _clean(m.group(2))
                    job["speed"] = _clean(m.group(3))
                    job["status"] = "processing" if pct >= 100 else "downloading"
                continue
            m = FILE_RE.match(line)
            if m:
                with self.lock:
                    job["filepath"] = m.group(1).strip()
                continue
            m = META_RE.match(line)
            if m:
                w, h, f = m.group(1), m.group(2), m.group(3)
                r = _res_of(w, h)
                with self.lock:
                    job["res"] = f"{r}p" if r else ""
                    try:
                        job["fps"] = str(round(float(f))) if f and f not in ("NA", "None") else ""
                    except ValueError:
                        job["fps"] = ""
                continue
            lines.append(line)
            if len(lines) > 200:
                del lines[:100]
            if line.startswith("ERROR:"):
                errors.append(line[6:].strip())
        proc.wait()
        shutil.rmtree(self.dir / "tmp" / job["id"], ignore_errors=True)
        with self.lock:
            self.procs.pop(job["id"], None)
        return proc.returncode, errors, lines

    def _log_failure(self, job: dict, lines: list[str]) -> None:
        try:
            log = self.dir / "woi.log"
            if log.exists() and log.stat().st_size > 1_000_000:
                log.unlink()
            stamp = time.strftime("%Y-%m-%d %H:%M:%S")
            with open(log, "a", encoding="utf-8") as fh:
                fh.write(f"\n===== {stamp} | {job['platform']} | {job['mode']} {job['quality']} {job.get('container', '')}\n")
                fh.write(job["url"] + "\n")
                fh.write("\n".join(lines) + "\n")
        except OSError:
            pass

    # ----- motor bakımı -----

    def versions(self) -> dict:
        out = {"ytdlp": "", "ffmpeg": "", "deno": bool(find_binary("deno"))}
        try:
            p = subprocess.run(self._run_args(["--version"]), capture_output=True, timeout=20,
                               env=self._env(), creationflags=NO_WINDOW)
            out["ytdlp"] = p.stdout.decode("utf-8", "replace").strip()
        except (OSError, RuntimeError, subprocess.TimeoutExpired):
            pass
        ff = find_binary("ffmpeg")
        if ff:
            try:
                p = subprocess.run([ff, "-version"], capture_output=True, timeout=20,
                                   creationflags=NO_WINDOW)
                first = p.stdout.decode("utf-8", "replace").splitlines()[0]
                m = re.search(r"version\s+(\S+)", first)
                out["ffmpeg"] = (m.group(1) if m else first)[:24]
            except (OSError, IndexError, subprocess.TimeoutExpired):
                pass
        return out

    def update_ytdlp(self) -> dict:
        try:
            p = subprocess.run(self._run_args(["-U"]), capture_output=True, timeout=180,
                               env=self._env(), creationflags=NO_WINDOW)
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
            return {"ok": False, "message": str(exc)}
        text = (p.stdout + p.stderr).decode("utf-8", "replace")
        if "up to date" in text.lower() or "güncel" in text.lower():
            msg = "Zaten güncel"
        elif "updated yt-dlp" in text.lower():
            msg = "Güncellendi"
        else:
            msg = "Güncellenemedi" if p.returncode else "Tamam"
        return {"ok": p.returncode == 0, "message": msg, "detail": text.strip()[-400:]}

    # ----- geçmiş -----

    def _load_history(self):
        try:
            items = json.loads((self.dir / "history.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return
        for j in items if isinstance(items, list) else []:
            if isinstance(j, dict) and j.get("id") and j.get("status") in ("done", "error", "canceled"):
                self.jobs[j["id"]] = j
                self.order.append(j["id"])

    def _save_history(self):
        with self.lock:
            items = [self.jobs[j] for j in self.order
                     if self.jobs[j]["status"] in ("done", "error", "canceled")][: self.HISTORY_LIMIT]
            data = json.dumps(items, ensure_ascii=False)
        try:
            (self.dir / "history.json").write_text(data, encoding="utf-8")
        except OSError:
            pass


def _strip_audio_mark(path: str) -> str:
    p = Path(path)
    if AUDIO_MARK not in p.stem or not p.exists():
        return path
    base = p.stem.replace(AUDIO_MARK, "")
    target = p.with_name(base + p.suffix)
    n = 2
    while target.exists():
        target = p.with_name(f"{base} ({n}){p.suffix}")
        n += 1
    try:
        p.rename(target)
        return str(target)
    except OSError:
        return path


def _res_of(width, height) -> int | None:
    """Çözünürlük, yt-dlp'deki gibi kısa kenar: dikey (1080x1920) video 1080p sayılır."""
    try:
        w = int(float(width)) if width not in (None, "", "NA", "None") else None
        h = int(float(height)) if height not in (None, "", "NA", "None") else None
    except (TypeError, ValueError):
        return None
    if w and h:
        return min(w, h)
    return h or w


def mp4_compatible(f: dict) -> bool:
    """Bu video biçimi yeniden kodlanmadan MP4'e konabilir mi?"""
    vc = f.get("vcodec")
    if vc and vc != "none":
        return bool(MP4_VCODEC_RE.match(vc))
    # kodek bilinmiyorsa (bazı siteler bildirmez) uzantıya bak
    return (f.get("ext") or "").lower() in ("mp4", "m4v", "mov")


def _best_video(info: dict, mp4_only: bool = False) -> tuple[int | None, int | None]:
    """Videonun sunduğu en yüksek çözünürlük ve o çözünürlükteki en yüksek fps.
    mp4_only: yalnızca MP4'e yeniden kodlamasız konabilen biçimler."""
    best_r, best_f = None, None
    formats = info.get("formats") or []
    for f in formats:
        if f.get("vcodec") == "none":
            continue
        if mp4_only and not mp4_compatible(f):
            continue
        r = _res_of(f.get("width"), f.get("height"))
        if not r:
            continue
        fps = f.get("fps")
        try:
            fps = round(float(fps)) if fps else None
        except (TypeError, ValueError):
            fps = None
        if best_r is None or r > best_r:
            best_r, best_f = r, fps
        elif r == best_r and fps and (best_f is None or fps > best_f):
            best_f = fps
    if best_r is None and not (mp4_only and formats):  # biçim listesi yoksa tekil bilgiye bak
        if mp4_only and not mp4_compatible(info):
            return None, None
        best_r = _res_of(info.get("width"), info.get("height"))
        try:
            best_f = round(float(info["fps"])) if info.get("fps") else None
        except (TypeError, ValueError):
            best_f = None
    return best_r, best_f


def _clean(s: str) -> str:
    s = (s or "").strip()
    return "" if s in ("NA", "N/A", "Unknown", "None") else s


def _last_error(stderr: str) -> str:
    lines = [l.strip() for l in stderr.splitlines() if l.strip()]
    errs = [l[6:].strip() for l in lines if l.startswith("ERROR:")]
    return errs[-1] if errs else (lines[-1] if lines else "")


def _kill_tree(proc: subprocess.Popen):
    try:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/T", "/F", "/PID", str(proc.pid)],
                           capture_output=True, creationflags=NO_WINDOW)
        else:
            proc.kill()
    except OSError:
        pass
