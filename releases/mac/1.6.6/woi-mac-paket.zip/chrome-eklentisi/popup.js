/* WOI Social Media Downloader – Chrome uzantısı */
'use strict';

const API = 'http://127.0.0.1:47771';
const VIDEO = ['2160p', '1440p', '1080p', '720p'];
const AUDIO = ['MP3', 'WAV'];
const PLATFORMS = [
  ['YouTube', ['youtube.com', 'youtu.be'], ['youtube.com']],
  ['Vimeo', ['vimeo.com'], ['vimeo.com']],
  ['Instagram', ['instagram.com'], ['instagram.com']],
  ['Facebook', ['facebook.com', 'fb.watch'], ['facebook.com']],
  ['X', ['x.com', 'twitter.com'], ['x.com', 'twitter.com']],
  ['TikTok', ['tiktok.com'], ['tiktok.com']],
  ['Pinterest', ['pinterest.com', 'pin.it'], ['pinterest.com']]
];
const PIN_HOST = /(^|\.)pinterest\.[a-z]{2,3}(\.[a-z]{2})?$/;  // pinterest.com.tr, pinterest.de …

const $ = (id) => document.getElementById(id);

// ---------------------------------------------------------------- dil (uygulamanın ayarını izler)
const I18N = {
  tr: {
    download: 'İndir', downloads: 'İndirilenler', video: 'Video', audio: 'Ses', mode: 'İndirme türü', quality: 'Kalite',
    best: 'En iyi', open_app: 'Uygulamayı aç', app_on: 'Uygulama bağlı', app_off: 'Uygulama kapalı',
    app_check: 'Uygulama kontrol ediliyor', reading: 'Sayfa okunuyor…', analyzing: 'Çözümleniyor…', no_video: 'Bu sayfada desteklenen video yok',
    app_closed: 'WOI uygulaması kapalı', app_closed_sub: 'Sağ üstteki simgeyle uygulamayı açın',
    mac_closed: 'WOI yardımcısı çalışmıyor', mac_closed_sub: 'Kur.command dosyasını yeniden çalıştırın',
    open_folder: 'İndirme klasörünü aç',
    sending: 'Gönderiliyor…', queued_ok: 'Kuyruğa eklendi', send_failed: 'Gönderilemedi', unreachable: 'Uygulamaya ulaşılamadı',
    queued: 'Sırada', starting: 'Hazırlanıyor', processing: 'İşleniyor', done: 'Tamamlandı', show_file: 'Klasörde göster',
    error: 'Hata', canceled: 'İptal edildi', empty: 'Henüz indirme yok',
    highest: 'En yüksek', na_video: 'Bu videoda yok', picked_any: 'En yüksek seçildi: ',
    codec_ok: 'H.264: QuickTime, Premiere ve her oynatıcıda açılır',
    codec_warn: ': en yüksek kalite; QuickTime ve Premiere açamayabilir, VLC ile oynatın', na_pre: '', na_post: ' için yok', container: 'Dosya biçimi', audio_fmt: 'Ses biçimi',
    max_pre: '', max_mid: ' için en yüksek ', picked_pre: '', picked_mid: ' için en yüksek: ',
    dl_as_pre: '', dl_as_post: ' indiriliyor',
    settings: 'Ayarlar', back: 'Geri', s_theme: 'Tema', theme_dark: 'Koyu', theme_light: 'Açık', s_lang: 'Dil',
    s_folder: 'İndirme klasörü', change: 'Değiştir', s_audio: 'Ses biçimi', s_default: 'Varsayılan',
    s_cookies: 'Giriş isteyen içerikler', ck_sub_win: 'Oturum nereden alınsın?', ck_sub_mac: 'Oturum Chrome’dan alınır',
    ck_extension: 'Chrome uzantısı', ck_chrome: 'Chrome', ck_none: 'Kullanma',
    s_updates: 'Sürüm ve güncellemeler', check: 'Denetle', update: 'Güncelle', up_to_date: 'güncel',
    upd_checking: 'Yeni sürüm denetleniyor…', new_ready: 'Yeni sürüm hazır: ', upd_downloading: 'Güncelleniyor · ',
    upd_waiting: 'İndirmeler bitince kurulacak', upd_wait_btn: 'Bekliyor', upd_installing: 'Kuruluyor…',
    upd_error: 'Denetlenemedi, internet bağlantısını kontrol edin', cancel: 'İndirmeyi iptal et',
    image: 'Görsel', image_note: 'Görsel, en yüksek çözünürlükte indirilir', settings_off: 'Ayarlar için uygulama açık olmalı',
    tt_none: 'Oynayan TikTok videosu bulunamadı', tt_none_sub: 'Videoyu açıp (ya da oynatıp) tekrar deneyin'
  },
  en: {
    download: 'Download', downloads: 'Downloads', video: 'Video', audio: 'Audio', mode: 'Download type', quality: 'Quality',
    best: 'Best', open_app: 'Open app', app_on: 'App connected', app_off: 'App closed',
    app_check: 'Checking app', reading: 'Reading page…', analyzing: 'Analyzing…', no_video: 'No supported video on this page',
    app_closed: 'WOI app is closed', app_closed_sub: 'Open the app with the icon at top right',
    mac_closed: 'WOI helper is not running', mac_closed_sub: 'Run Kur.command again',
    open_folder: 'Open download folder',
    sending: 'Sending…', queued_ok: 'Added to queue', send_failed: 'Could not send', unreachable: 'App not reachable',
    queued: 'Queued', starting: 'Preparing', processing: 'Processing', done: 'Completed', show_file: 'Show in folder',
    error: 'Error', canceled: 'Canceled', empty: 'No downloads yet',
    highest: 'Highest', na_video: 'Not available for this video', picked_any: 'Highest selected: ',
    codec_ok: 'H.264: opens in QuickTime, Premiere and every player',
    codec_warn: ': top quality; QuickTime and Premiere may not open it, play it with VLC', na_pre: 'Not available in ', na_post: '', container: 'File format', audio_fmt: 'Audio format',
    max_pre: 'Highest for ', max_mid: ': ', picked_pre: 'Highest for ', picked_mid: ': ',
    dl_as_pre: 'Downloading ', dl_as_post: '',
    settings: 'Settings', back: 'Back', s_theme: 'Theme', theme_dark: 'Dark', theme_light: 'Light', s_lang: 'Language',
    s_folder: 'Download folder', change: 'Change', s_audio: 'Audio format', s_default: 'Default',
    s_cookies: 'Content that needs login', ck_sub_win: 'Where should your session come from?', ck_sub_mac: 'Session comes from Chrome',
    ck_extension: 'Chrome extension', ck_chrome: 'Chrome', ck_none: 'Don’t use',
    s_updates: 'Version and updates', check: 'Check', update: 'Update', up_to_date: 'up to date',
    upd_checking: 'Checking for a new version…', new_ready: 'New version ready: ', upd_downloading: 'Updating · ',
    upd_waiting: 'Will install when downloads finish', upd_wait_btn: 'Waiting', upd_installing: 'Installing…',
    upd_error: 'Could not check, check your internet connection', cancel: 'Cancel download',
    image: 'Image', image_note: 'Image, downloaded at full resolution', settings_off: 'The app must be running for settings',
    tt_none: 'No playing TikTok video found', tt_none_sub: 'Open (or play) the video and try again'
  },
};
const ENGINE_EN = {
  'Giriş gerekli': 'Login required', 'Özel içerik': 'Private content', 'Desteklenmeyen bağlantı': 'Unsupported link',
  'Biçim bulunamadı': 'Format not available', 'İçerik bulunamadı': 'Content not found', 'Bağlantı hatası': 'Connection error',
  'Hata': 'Error', 'Geçerli bir bağlantı değil.': 'Not a valid link.', 'Diğer': 'Other', 'Görsel': 'Image'
};
let lang = 'tr';
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const t = (k) => { const d = I18N[lang] || I18N.tr; return has(d, k) ? d[k] : has(I18N.tr, k) ? I18N.tr[k] : k; };
const te = (x) => (lang === 'en' && ENGINE_EN[x]) || x;
const pctText = (n) => (lang === 'en' ? n + '%' : '%' + n);

function applyLanguage() {
  document.documentElement.lang = lang;
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach((el) => { el.setAttribute('aria-label', t(el.dataset.i18nAria)); });
  document.querySelectorAll('[data-i18n-title]').forEach((el) => { el.title = t(el.dataset.i18nTitle); });
}
const st = {
  tab: null, url: '', platform: null, online: false, settings: null,
  mode: 'video', container: 'mp4', analyzing: false, quality: { video: '2160p', audio: 'MP3' }, title: '', jobId: null,
  info: null
};

function detect(url) {
  let host = '';
  try { host = new URL(url).hostname.toLowerCase(); } catch (e) { return null; }
  if (PIN_HOST.test(host)) return PLATFORMS.find((p) => p[0] === 'Pinterest');
  for (const p of PLATFORMS) {
    if (p[1].some((d) => host === d || host.endsWith('.' + d))) return p;
  }
  return null;
}

function cleanTitle(t) {
  return (t || '')
    .replace(/^\(\d+\)\s*/, '')
    .replace(/\s*[-|•]\s*(YouTube|Vimeo|Instagram|Facebook|TikTok|X|Pinterest)\s*$/i, '')
    .replace(/\s+on X:.*$/i, '')
    .trim();
}

// TikTok akışında (Sana Özel, Takip, profil) sekme adresi videonun adresi değil:
// sayfada oynayan videonun kimliği ve kullanıcısı bulunur, indirilebilir adres kurulur.
const TT_VIDEO = /tiktok\.com\/(?:@[\w.-]+\/)?(?:video|photo)\/\d+/;
function findPlayingTikTok() {
  const vh = window.innerHeight, vw = window.innerWidth;
  const score = (v) => {
    const r = v.getBoundingClientRect();
    const h = Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0));
    const w = Math.max(0, Math.min(r.right, vw) - Math.max(r.left, 0));
    return h * w + (v.paused ? 0 : 1e9);
  };
  const vids = [...document.querySelectorAll('video')].filter((v) => score(v) > 0).sort((a, b) => score(b) - score(a));
  const fromHref = (h) => { const m = String(h || '').match(/@([\w.-]+)\/(?:video|photo)\/(\d+)/); return m ? { user: m[1], id: m[2] } : null; };
  for (const v of vids.slice(0, 3)) {
    let id = null, user = null;
    for (let el = v, i = 0; el && i < 30; el = el.parentElement, i++) {
      if (!id) { const m = (el.id || '').match(/(\d{17,21})/); if (m) id = m[1]; }
      if (el.querySelectorAll) {
        if (!id) {
          for (const a of el.querySelectorAll('a[href*="/video/"], a[href*="/photo/"]')) {
            const r = fromHref(a.getAttribute('href'));
            if (r) { id = r.id; user = r.user; break; }
          }
        }
        if (!user) {
          const a = el.querySelector('a[href^="/@"], a[href*="tiktok.com/@"]');
          const m = a && (a.getAttribute('href') || '').match(/@([\w.-]+)/);
          if (m) user = m[1];
        }
      }
      if (id && user) break;
    }
    if (id) return 'https://www.tiktok.com/@' + (user || '_') + '/video/' + id;
  }
  return null;
}
async function resolveTikTok(tab, url) {
  if (TT_VIDEO.test(url) || /(?:vm|vt)\.tiktok\.com\//.test(url)) return url;
  try {
    const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: findPlayingTikTok });
    return (res && res.result) || null;
  } catch (e) { return null; }
}

async function call(path, body) {
  const opts = body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    : {};
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), path === '/info' ? 95000 : 8000);
  try {
    const r = await fetch(API + path, { ...opts, signal: ctrl.signal });
    return await r.json();
  } finally {
    clearTimeout(timer);
  }
}

async function cookiesFor(platform) {
  if (!platform || !st.settings || st.settings.cookies_source !== 'extension') return undefined;
  const out = [];
  for (const domain of platform[2]) {
    try {
      const list = await chrome.cookies.getAll({ domain });
      for (const c of list) {
        out.push({
          domain: c.domain, name: c.name, value: c.value, path: c.path, secure: c.secure,
          httpOnly: c.httpOnly, hostOnly: c.hostOnly, expirationDate: c.expirationDate || 0
        });
      }
    } catch (e) { /* izin yoksa geç */ }
  }
  return out;
}

// ---------------------------------------------------------------- görünüm
function setStatus(kind) {
  const el = $('status');
  el.className = 'status' + (kind === 'on' ? ' on' : kind === 'off' ? ' off' : '');
  const label = t(kind === 'on' ? 'app_on' : kind === 'off' ? 'app_off' : 'app_check');
  el.setAttribute('aria-label', label);
  el.title = label;
}

let mediaState = null;  // [title, meta, warn] – not gösterildikten sonra geri dönmek için
function setMedia(title, meta, warn) {
  mediaState = [title, meta, warn];
  $('title').textContent = title;
  $('title').className = 'title' + (warn ? ' warn' : '');
  const m = $('meta');
  m.classList.remove('note');
  m.textContent = meta || '\u00a0';
  if (st.analyzing && !warn) {  // çözümleme sürerken
    m.appendChild(document.createTextNode(' · '));
    const b = document.createElement('span');
    b.className = 'busy';
    b.textContent = t('analyzing');
    m.appendChild(b);
  } else if (maxRes() && !warn && st.mode === 'video' && !isImage()) {
    m.appendChild(document.createTextNode(' · '));
    const mx = document.createElement('span');
    mx.id = 'm-max';
    mx.textContent = t('highest') + ' ' + maxRes() + 'p' + (maxFps() ? ' ' + maxFps() + ' fps' : '');
    m.appendChild(mx);
  }
}

let noteTimer = null;
function showNote(text) {
  clearTimeout(noteTimer);
  const m = $('meta');
  m.textContent = text;
  m.classList.add('note');
  noteTimer = setTimeout(() => { if (mediaState) setMedia(...mediaState); }, 3000);
}

const qHeight = (q) => parseInt(q, 10) || 0;
const boxName = () => 'MP4';
const isImage = () => !!(st.info && st.info.is_image);
// Videonun MP4 olarak indirilebilecek en yüksek çözünürlüğü ve fps'i (tüm videolar MP4)
const useMp4 = () => !!(st.info && st.info.max_mp4);
// 1.6.6: en yüksek çözünürlük kodek ne olursa olsun; her çözünürlüğün kodeki düğmede yazar
const maxRes = () => (st.info ? (st.info.max_res || st.info.max_mp4) : null);
const maxFps = () => (st.info ? (st.info.max_fps || st.info.max_fps_mp4) : null);
const codecOf = (q) => (st.info && st.info.codecs && st.info.codecs[String(qHeight(q))]) || '';
const codecTip = (c) => (!c ? '' : c === 'H.264' ? t('codec_ok') : c + t('codec_warn'));
function isAvailable(q) {
  if (st.mode !== 'video' || !maxRes()) return true;
  return qHeight(q) <= maxRes();
}
function bestAvailable() {
  return VIDEO.find(isAvailable) || VIDEO[VIDEO.length - 1];
}
function flashButton(q, times) {
  const b = [...$('quality').children].find((x) => x.dataset.q === q);
  if (!b) return;
  b.classList.remove('flash');
  void b.offsetWidth;
  b.style.animationIterationCount = times;
  b.classList.add('flash');
}
function flashMax() {
  const m = $('m-max');
  if (!m) return;
  m.classList.remove('flash');
  void m.offsetWidth;
  m.classList.add('flash');
}
const fpsText = () => (maxFps() ? ' · ' + maxFps() + ' fps' : '');

// Videoda yalnızca çözünürlük; seste WAV | MP3. Seste çözünürlük yok.
const fmtPair = () => ['WAV', 'MP3'];
function pickFmt(side) {
  st.quality.audio = fmtPair()[side];
  renderQuality();
  if (mediaState) setMedia(...mediaState);
}
function renderQuality() {
  const image = isImage() && !st.analyzing;
  const video = st.mode === 'video';
  const list = video && !image ? VIDEO : [];
  const cur = st.quality.video;
  $('modes').hidden = image;  // görsel pin: tür ve kalite seçimi yok
  $('mode-video').setAttribute('aria-pressed', video);
  $('mode-audio').setAttribute('aria-pressed', !video);
  const pair = fmtPair();
  $('fmt').hidden = video || image;
  $('fmt-left').setAttribute('aria-pressed', st.quality.audio === pair[0]);
  $('fmt-right').setAttribute('aria-pressed', st.quality.audio === pair[1]);
  $('quality').innerHTML = '';
  if (image) {
    const n = document.createElement('span');
    n.className = 'img-note';
    n.textContent = t('image_note');
    $('quality').appendChild(n);
  }
  for (const q of list) {
    const b = document.createElement('button');
    const r = document.createElement('span');
    r.className = 'q-res';
    r.textContent = q;
    b.appendChild(r);
    b.dataset.q = q;
    if (st.analyzing) {  // çözümlenirken hepsi pasif, hiçbiri seçili görünmez
      b.className = 'busy';
      b.setAttribute('aria-pressed', 'false');
      b.setAttribute('aria-disabled', 'true');
      b.title = t('analyzing');
      $('quality').appendChild(b);
      continue;
    }
    b.setAttribute('aria-pressed', q === cur);
    const ok = isAvailable(q);
    if (!ok) {
      b.className = 'na';
      b.setAttribute('aria-disabled', 'true');
      b.title = t('na_video');
    } else if (codecOf(q)) {
      const c = document.createElement('span');
      c.className = 'q-codec';
      c.textContent = codecOf(q);
      b.appendChild(c);
      if (codecOf(q) !== 'H.264') b.className = 'alt';
      b.title = codecTip(codecOf(q));
    }
    b.onclick = () => {
      if (!ok) {
        // Videoda olmayan çözünürlük seçilemez: en yüksek mevcut olan seçilir, 3 kez parlar
        const best = bestAvailable();
        st.quality.video = best;
        renderQuality();
        persist();
        flashButton(best, 3);
        flashMax();
        return;
      }
      st.quality.video = q;
      renderQuality();
      persist();
    };
    $('quality').appendChild(b);
  }
}

function updateButton() {
  $('download').disabled = !(st.online && st.platform) || st.analyzing;
}

function persist() {
  // MP4 ve ses biçimi her açılışta varsayılandan başlar; yalnızca tür ve çözünürlük hatırlanır
  try { chrome.storage.local.set({ mode: st.mode, video: st.quality.video }); } catch (e) { /* yok say */ }
}

// ---------------------------------------------------------------- son indirilenler
const ICON_X = '<svg aria-hidden="true" width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>';
function jobRow(j) {
  const row = document.createElement('div');
  row.className = 'job';
  const top = document.createElement('div');
  top.className = 'job-top';
  const title = document.createElement('span');
  title.className = 'job-title';
  title.textContent = j.title || '';
  title.title = j.title || '';
  const metaParts = j.mode === 'audio' ? [j.quality] : j.mode === 'image' ? [t('image')]
    : (j.res ? [j.res].concat(j.fps ? [j.fps + ' fps'] : []) : []);
  if (j.mode === 'video' && metaParts.length) {
    const ext = (j.filepath || '').split('.').pop().toLowerCase();
    const box = ext === 'mp4' || ext === 'mkv' ? ext : (j.container || '');
    if (j.codec && j.codec !== 'H.264') metaParts.push(j.codec);
    if (box) metaParts.push(box.toUpperCase());
  }
  if (metaParts.length) {
    const sm = document.createElement('span');
    sm.className = 'job-meta';
    sm.textContent = ' · ' + metaParts.join(' · ');
    title.appendChild(sm);
  }
  const pct = Math.round(j.percent || 0);
  let right;
  if (j.status === 'done') {
    right = document.createElement('button');
    right.className = 'job-right done';
    right.textContent = t('done');
    right.title = t('show_file');
    right.onclick = () => { call('/reveal', { id: j.id }).catch(() => {}); };
  } else {
    right = document.createElement('span');
    right.className = 'job-right' + (j.status === 'error' ? ' err' : '');
    right.textContent = {
      queued: t('queued'), starting: t('starting'), downloading: pctText(pct), processing: t('processing'),
      error: te(j.error || 'Hata'), canceled: t('canceled')
    }[j.status] || '';
    if (j.status === 'error' && j.detail) right.title = j.detail;
    // Süren indirme: yüzdenin sağında iptal çarpısı
    if (['queued', 'starting', 'downloading', 'processing'].includes(j.status)) {
      const x = document.createElement('button');
      x.className = 'job-x';
      x.setAttribute('aria-label', t('cancel'));
      x.title = t('cancel');
      x.innerHTML = ICON_X;
      x.onclick = async () => {
        x.disabled = true;
        try { await call('/cancel', { id: j.id }); } catch (e) { /* yok say */ }
        pollJobs();
      };
      right.appendChild(x);
    }
  }
  top.append(title, right);
  row.appendChild(top);
  if (j.status === 'downloading' || j.status === 'processing' || j.status === 'starting') {
    const bar = document.createElement('div');
    bar.className = 'bar';
    const fill = document.createElement('div');
    fill.style.width = (j.status === 'downloading' ? pct : 100) + '%';
    bar.appendChild(fill);
    row.appendChild(bar);
  }
  return row;
}

let lastJobsKey = '';
function renderJobs(jobs) {
  const key = JSON.stringify((jobs || []).map((j) => [j.id, j.status, Math.round(j.percent || 0), j.title, j.res, j.filepath]));
  if (key === lastJobsKey) return;
  lastJobsKey = key;
  const box = $('jobs');
  box.innerHTML = '';
  if (!jobs || !jobs.length) {
    const e = document.createElement('div');
    e.className = 'empty';
    e.textContent = t('empty');
    box.appendChild(e);
    return;
  }
  for (const j of jobs.slice(0, 3)) box.appendChild(jobRow(j));
}

async function pollJobs() {
  if (!st.online) return;
  try {
    const r = await call('/jobs');
    renderJobs((r && r.jobs) || []);
  } catch (e) { /* uygulama kapandıysa sessiz */ }
}

// ---------------------------------------------------------------- akış
async function download() {
  if ($('download').disabled || st.analyzing) return;
  const mode = isImage() ? 'image' : st.mode;
  if (mode === 'image') {
    showNote(t('dl_as_pre') + t('image') + t('dl_as_post'));
  } else if (st.mode === 'video') {
    let q = st.quality.video;
    const picked = !isAvailable(q);
    if (picked) { q = bestAvailable(); st.quality.video = q; renderQuality(); persist(); }
    flashButton(q, 2);
    showNote(picked ? t('picked_any') + q + fpsText() + (codecOf(q) ? ' · ' + codecOf(q) : '')
                    : t('dl_as_pre') + q + fpsText() + ' · ' + (codecOf(q) ? codecOf(q) + ' ' : '') + boxName() + t('dl_as_post'));
  } else {
    showNote(t('dl_as_pre') + st.quality.audio + t('dl_as_post'));
  }
  $('download').disabled = true;
  $('download').textContent = t('sending');
  try {
    const res = await call('/download', {
      url: st.url, mode, quality: mode === 'image' ? '' : st.quality[st.mode], container: 'mp4',
      codec: mode === 'video' ? (codecOf(st.quality.video) || undefined) : undefined,
      title: st.title || undefined, cookies: await cookiesFor(st.platform)
    });
    if (res && res.ok) {
      st.jobId = res.job.id;
      track(res.job);
      pollJobs();
      $('download').textContent = t('queued_ok');
    } else {
      $('download').textContent = te(res && res.error) || t('send_failed');
    }
  } catch (e) {
    $('download').textContent = t('unreachable');
  }
  setTimeout(() => { $('download').textContent = t('download'); updateButton(); }, 1800);
}

// Arka plan, iş bitince "İndirme tamamlandı" bildirimini gösterir (background.js)
function track(job) {
  try { chrome.runtime.sendMessage({ type: 'track', id: job.id, title: job.title || st.title || '' }); } catch (e) { /* yok say */ }
}

// Mac'te masaüstü penceresi yok: arka plan yardımcısı çalışır, simge indirme klasörünü açar
const IS_MAC = /mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || navigator.userAgent);
const FOLDER_ICON = '<svg aria-hidden="true" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 7.5A2.5 2.5 0 0 1 5.5 5h3.6l2 2h7.4A2.5 2.5 0 0 1 21 9.5v8a2.5 2.5 0 0 1-2.5 2.5h-13A2.5 2.5 0 0 1 3 17.5z"/></svg>';
function setupMac() {
  if (!IS_MAC) return;
  const b = $('open-app');
  b.innerHTML = FOLDER_ICON;
  b.dataset.i18nAria = 'open_folder';
  b.dataset.i18nTitle = 'open_folder';
  b.setAttribute('aria-label', t('open_folder'));
  b.title = t('open_folder');
}

// ---------------------------------------------------------------- tema ve ayarlar
function applyTheme(theme) {
  const light = theme === 'light';
  document.documentElement.setAttribute('data-theme', light ? 'light' : 'dark');
  $('theme-dark').setAttribute('aria-pressed', !light);
  $('theme-light').setAttribute('aria-pressed', light);
  try { localStorage.setItem('woi-theme', light ? 'light' : 'dark'); } catch (e) { /* yok say */ }
}

function setLang(l) {
  if ((l !== 'en' && l !== 'tr') || l === lang) return;
  lang = l;
  try { chrome.storage.local.set({ lang }); } catch (e) { /* yok say */ }
  applyLanguage();
  renderQuality();
  lastJobsKey = '';
  pollJobs();
  if (mediaState && st.platform && st.online) setMedia(st.title || st.platform[0], mediaState[1]);
  if (st.settings) renderSettings(st.settings);
}

function shortPath(p) {
  return String(p || '').replace(/^\/Users\/[^/]+/, '~');
}

function renderSettings(s) {
  st.settings = s;
  applyTheme(s.theme);
  $('s-lang').value = s.language === 'en' ? 'en' : 'tr';
  $('s-folder').textContent = shortPath(s.folder);
  $('s-folder').title = s.folder || '';
  $('s-audio').value = AUDIO.includes(s.audio_format) ? s.audio_format : 'MP3';
  const mac = s.platform === 'mac' || IS_MAC;
  const opts = mac ? [['extension', t('ck_chrome')], ['none', t('ck_none')]]
    : [['extension', t('ck_chrome')], ['firefox', 'Firefox'], ['edge', 'Edge'], ['none', t('ck_none')]];
  const cur = opts.some((o) => o[0] === s.cookies_source) ? s.cookies_source : 'extension';
  $('s-cookies').innerHTML = '';
  for (const [v, label] of opts) {
    const o = document.createElement('option');
    o.value = v;
    o.textContent = label;
    $('s-cookies').appendChild(o);
  }
  $('s-cookies').value = cur;
  $('s-cookies-sub').textContent = t(mac ? 'ck_sub_mac' : 'ck_sub_win');
  renderUpdate(s.update || { status: 'idle', current: s.version });
}

function renderUpdate(u) {
  u = u || {};
  const cur = u.current || (st.settings && st.settings.version) || '';
  const isNew = ['available', 'downloading', 'waiting', 'installing'].includes(u.status);
  let text = 'WOI ' + cur + (u.status === 'uptodate' ? ' · ' + t('up_to_date') : '');
  let cls = '', label = t('check'), disabled = false, accent = false;
  switch (u.status) {
    case 'checking': text = t('upd_checking'); cls = 'busy'; disabled = true; break;
    case 'available': text = t('new_ready') + u.latest; cls = 'hi'; label = t('update'); accent = true; break;
    case 'downloading': text = t('upd_downloading') + pctText(u.percent || 0); cls = 'busy'; label = t('update'); disabled = true; break;
    case 'waiting': text = t('upd_waiting'); cls = 'hi'; label = t('upd_wait_btn'); disabled = true; break;
    case 'installing': text = t('upd_installing'); cls = 'busy'; label = t('update'); disabled = true; break;
    case 'error': text = t('upd_error'); break;
  }
  const sub = $('s-version');
  sub.textContent = text;
  sub.title = text;
  sub.className = 'ssub' + (cls ? ' ' + cls : '');
  const b = $('s-update');
  b.textContent = label;
  b.disabled = disabled;
  b.className = 'sbtn' + (accent ? ' accent' : '');
  $('upd-row').classList.toggle('new', isNew);
  $('upd-dot').hidden = !isNew;
  st.update = u;
}

async function saveSettings(changes) {
  try {
    const s = await call('/settings', changes);
    if (s && s.ok) renderSettings(s);
    if (s && s.language) setLang(s.language);
  } catch (e) { /* uygulama kapandıysa sessiz */ }
}

let settingsTimer = null;
function showSettings(open) {
  $('view-main').hidden = open;
  $('view-settings').hidden = !open;
  clearInterval(settingsTimer);
  if (!open) return;
  if (st.settings) renderSettings(st.settings);
  const refresh = async () => {
    try {
      const s = await call('/settings');
      if (s && s.ok) { renderSettings(s); setLang(s.language); }
    } catch (e) { /* yok say */ }
  };
  refresh();
  settingsTimer = setInterval(refresh, 1000);  // güncelleme durumu ve uygulamadan gelen değişiklikler
}

function bindSettings() {
  $('open-settings').onclick = () => { if (st.online) showSettings(true); };
  $('close-settings').onclick = () => showSettings(false);
  const pickTheme = (v) => { if (st.settings) st.settings.theme = v; applyTheme(v); saveSettings({ theme: v }); };
  $('theme-dark').onclick = () => pickTheme('dark');
  $('theme-light').onclick = () => pickTheme('light');
  $('s-lang').onchange = (e) => {
    const v = e.target.value;
    if (st.settings) st.settings.language = v;
    setLang(v);
    saveSettings({ language: v });
  };
  $('s-audio').onchange = (e) => {
    st.quality.audio = e.target.value;
    renderQuality();
    saveSettings({ audio_format: e.target.value });
  };
  $('s-cookies').onchange = (e) => saveSettings({ cookies_source: e.target.value });
  // Klasör seçme penceresi açılınca bu pencere kapanır; seçim uygulamaya/yardımcıya kaydedilir
  $('s-choose').onclick = () => { call('/choose-folder', {}).catch(() => {}); };
  $('s-update').onclick = async () => {
    const u = st.update || {};
    renderUpdate(u.status === 'available' ? { ...u, status: 'downloading', percent: 0 } : { ...u, status: 'checking' });
    try {
      const r = await call(u.status === 'available' ? '/update-install' : '/update-check', {});
      if (r && r.update) renderUpdate(r.update);
    } catch (e) { /* yok say */ }
  };
}

// Uygulama/yardımcı güncellendiyse eklenti dosyaları da yenilenmiştir: Chrome'a yeniden yükletilir
function newer(a, b) {
  const pa = String(a || '').split('.').map((x) => parseInt(x, 10) || 0);
  const pb = String(b || '').split('.').map((x) => parseInt(x, 10) || 0);
  for (let i = 0; i < 3; i++) { if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0); }
  return false;
}
async function reloadIfOutdated(ping) {
  try {
    const mine = chrome.runtime.getManifest().version;
    if (!ping || !newer(ping.version, mine)) return false;
    const { reloadedFor } = await chrome.storage.local.get('reloadedFor');
    if (reloadedFor === ping.version) return false;  // dosyalar yenilenmemişse döngüye girme
    await chrome.storage.local.set({ reloadedFor: ping.version });
    chrome.runtime.reload();
    return true;
  } catch (e) { return false; }
}

async function openApp() {
  if (IS_MAC && !st.online) return;  // yardımcı kapalıysa açılacak bir şey yok
  if (st.online) {
    try { await call('/focus', {}); } catch (e) { /* yok say */ }
  } else if (st.tab) {
    // Kurulumda kaydedilen woi:// adresi uygulamayı başlatır.
    chrome.tabs.update(st.tab.id, { url: 'woi://open' });
  }
  window.close();
}

async function init() {
  const remedia = () => { if (mediaState) setMedia(...mediaState); };
  $('mode-video').onclick = () => { st.mode = 'video'; renderQuality(); persist(); remedia(); };
  $('mode-audio').onclick = () => { st.mode = 'audio'; renderQuality(); persist(); remedia(); };
  $('fmt-left').onclick = () => pickFmt(0);
  $('fmt-right').onclick = () => pickFmt(1);
  $('download').onclick = download;
  $('open-app').onclick = openApp;
  bindSettings();
  try { $('ext-version').textContent = ' · v' + chrome.runtime.getManifest().version; } catch (e) { /* yok say */ }

  try {
    const saved = await chrome.storage.local.get(['mode', 'video', 'quality', 'lang']);
    if (saved.mode === 'video' || saved.mode === 'audio') st.mode = saved.mode;
    const v = saved.video || (saved.quality && saved.quality.video);  // eski sürüm 'quality' saklıyordu
    if (VIDEO.includes(v)) st.quality.video = v;
    if (saved.lang) lang = saved.lang;
  } catch (e) { /* yok say */ }
  setupMac();
  applyLanguage();
  setMedia(t('reading'), '');
  renderQuality();
  renderJobs([]);

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  st.tab = tab;
  st.url = (tab && tab.url) || '';
  st.platform = detect(st.url);
  st.title = cleanTitle(tab && tab.title);
  let ttMissing = false;
  if (st.platform && st.platform[0] === 'TikTok') {
    const u = await resolveTikTok(tab, st.url);
    if (u) {
      if (u !== st.url) st.title = '';  // akıştaki sekme başlığı videonun başlığı değil
      st.url = u;
    } else ttMissing = true;
  }

  // Uygulama açık mı?
  try {
    const ping = await call('/ping');
    st.online = !!(ping && ping.ok);
    if (st.online && await reloadIfOutdated(ping)) return;
    if (ping && ping.ok) {
      renderSettings(ping);
      setLang(ping.language);
      if (AUDIO.includes(ping.audio_format)) st.quality.audio = ping.audio_format;  // varsayılan MP3
      renderQuality();
    }
  } catch (e) {
    st.online = false;
  }
  setStatus(st.online ? 'on' : 'off');
  $('open-settings').disabled = !st.online;
  $('open-settings').title = st.online ? t('settings') : t('settings_off');
  st.analyzing = !!(st.online && st.platform);
  renderQuality();

  if (ttMissing) {
    st.platform = null;
    st.analyzing = false;
    renderQuality();
    setMedia(t('tt_none'), t('tt_none_sub'), true);
  } else if (!st.platform) {
    setMedia(t('no_video'), 'YouTube · Vimeo · Instagram · Facebook · X · TikTok · Pinterest', true);
  } else if (!st.online) {
    if (IS_MAC) setMedia(t('mac_closed'), t('mac_closed_sub'), true);
    else setMedia(t('app_closed'), t('app_closed_sub'), true);
  } else {
    setMedia(st.title || st.platform[0], st.platform[0]);
  }
  updateButton();
  if (!st.online) return;

  pollJobs();
  setInterval(pollJobs, 800);

  if (st.platform) {
    let info = null;
    try {
      info = await call('/info', { url: st.url, cookies: await cookiesFor(st.platform) });
    } catch (e) { /* sayfa başlığıyla devam */ }
    st.analyzing = false;
    if (info && info.ok) {
      st.title = info.title;
      st.info = info;
      // En yüksek çözünürlük bulundu: indirilebilecek en yükseği seçili gelir
      st.quality.video = bestAvailable();
      renderQuality();
      setMedia(info.title, [te(info.platform), info.is_image ? t('image') : info.duration].filter(Boolean).join(' · '));
    } else {
      renderQuality();
      setMedia(st.title || st.platform[0], st.platform[0] + (info && info.error ? ' · ' + te(info.error) : ''), false);
    }
    updateButton();
  }
}

init();
